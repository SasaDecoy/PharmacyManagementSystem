package adminOptions;

import mainClasses.User;
import mainClasses.Option;
import java.util.*;
import publicOptions.ManageAccount;
import static utils.CommonFunctions.*;

public class ManageUsers implements Option {

    @Override
    public String getOption() {
        return "👤 Manage Users ";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- Manage Users ---");
        ArrayList<User> allUsers = loadAllUsers(null);
        viewAllUsers();

        while (true) {
            String username = getStringInput(s, "Enter the username/ID of the user to manage (0 to Exit): ");

            if (username.equals("0")) {
                System.out.println("\n==Returning to menu==");
                return;
            }

            for (User user : allUsers) {
                if (String.valueOf(user.getId()).equals(username) || user.getUsername().equalsIgnoreCase(username)) {
                    new ManageAccount().oper(s, user);
                    break;
                }
            }
            System.out.println("❌ User was not found! Try again.");
        }
    }

}
