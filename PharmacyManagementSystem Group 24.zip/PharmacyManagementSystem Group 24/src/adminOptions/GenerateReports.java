package adminOptions;

import java.time.LocalDate;
import java.util.*;
import mainClasses.*;
import publicOptions.ViewAllMedicines;
import static utils.CommonFunctions.*;

public class GenerateReports implements Option {

    @Override
    public String getOption() {
        return "📊 Generate Reports";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- Generate Reports ---");
        while (true) {
            System.out.println("\n1. Search for a Medicine");
            System.out.println("2. Calculate Total Amount of Medicine in Pharmacy");
            System.out.println("3. Display Revenue of a Specific Medicine");
            System.out.println("4. Display expiring Medicines");
            System.out.println("0. Exit");
            int choice = getIntInput(s, "Choose an option: ");

            if (choice == 0) {
                System.out.println("\n==Returning to menu==");
                break;
            }

            switch (choice) {
                case 1 -> {
                    String input = getStringInput(s, "Enter medicine ID/Name to search for (0 to Cancel): ");
                    if (input.equals("0")) {
                        System.out.println("\n==Canceled==");
                        break;
                    }
                    if(findMedicineByIdOrName(input) == null){
                        System.out.println("⚠️ Medicine not found.");
                    }else{
                        findMedicineByIdOrName(input).displayInfo();
                    }
                }
                case 2 ->
                    calculateTotalMedicine();
                case 3 ->
                    displayMedicineRevenue(s);
                case 4 -> {
                    LocalDate date = getDateInput(s, "Enter the minimum expiry (d/M/YYYY) or leave blank: ");
                    displayExpiry(date);
                }
                default ->
                    System.out.println("❌ Invalid choice!");
            }
        }
    }

    private void calculateTotalMedicine() {
        int totalStock = 0;

        ArrayList<Medicine> allMedicines = loadMedicines();

        if (allMedicines.isEmpty()) {
            System.out.println("⚠ No medicnies found in the pharmacy.️");
        } else {
            for (Medicine med : allMedicines) {
                totalStock += med.getStock();
            }
            System.out.println("\n📦 Total Medicine Stock in Pharmacy: " + totalStock + " Medicines.");
        }

    }

    private void displayMedicineRevenue(Scanner s) {
        new ViewAllMedicines().oper(s, null);
        int medicineId = getIntInput(s, "Enter Medicine ID to calculate revenue (0 to Cancel): ");
        double totalRevenue;
        double pricePerUnit;
        int totalUnits = 0;

        if (medicineId == 0) {
            System.out.println("\n==Canceled==");
            return;
        }

        Medicine selectedMedicine = findMedicineById(medicineId);
        ArrayList<Order> allOrders = loadOrdersByCustomerId(0);
        pricePerUnit = selectedMedicine.getPrice();

        if (selectedMedicine == null) {
            System.out.println("❌ Medicine not found.");
            return;
        }

        for (Order order : allOrders) {
            ArrayList<Medicine> orderMedicines = order.getMedicines();
            ArrayList<Integer> orderQuantities = order.getQuantities();
            for (int i = 0; i < orderMedicines.size(); i++) {
                if (orderMedicines.get(i).getId() == selectedMedicine.getId()) {
                    totalUnits += orderQuantities.get(i);
                }
            }
        }

        totalRevenue = pricePerUnit * totalUnits;

        System.out.println("\n💰 Revenue Report for Medicine ID: " + medicineId);
        System.out.println("Total Units Sold: " + totalUnits);
        System.out.println("Price per Unit: $" + pricePerUnit);
        System.out.println("Total Revenue: $" + totalRevenue);
    }

    private void displayExpiry(LocalDate date) {

        boolean checkUpcoming = false;

        if (date == null) {
            date = LocalDate.now();
            checkUpcoming = true;
        }

        ArrayList<Medicine> allMedicines = loadMedicines();
        
        if (allMedicines.isEmpty()) {
            System.out.println("⚠ No medicnies found in the pharmacy.️");
            return;
        }
        
        LocalDate oneMonthLater = date.plusMonths(1);

        for (Medicine med : allMedicines) {
            LocalDate medDate = med.getExpirationDate();

            if (checkUpcoming) {
                if (medDate.isBefore(oneMonthLater)) {
                    med.displayInfo();
                }
            } else {
                if (medDate.isBefore(date)) {
                    med.displayInfo();
                }
            }
        }
    }

}
