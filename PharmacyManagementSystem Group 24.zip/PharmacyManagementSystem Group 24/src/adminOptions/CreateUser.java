package adminOptions;

import mainClasses.User;
import mainClasses.Doctor;
import mainClasses.Admin;
import mainClasses.Client;
import mainClasses.Option;
import java.util.*;
import static utils.CommonFunctions.*;

public class CreateUser implements Option {

    @Override
    public String getOption() {
        return "➕ Create User";
    }  

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- Create a New User ---");
        System.out.println("1. Create Client");
        System.out.println("2. Create Doctor");
        System.out.println("3. Create Admin");
        System.out.println("0. Exit");

        int choice = getIntInput(s, "Choose an option: ");
        
        if (choice == 0) {
            System.out.println("\n==Returning to menu==");
            return;
        }

        String name = getStringInput(s, "Enter Name: ");

        String username;
        while (true) {
            username = getStringInput(s, "Enter Username: ");

            if (checkUsername(username)) {
                break;
            }
            System.out.println("❌ Username already exists! Try again.");
        }

        String phone = getStringInput(s, "Enter Phone Number: ");
        String dateOfBirth = getStringInput(s, "Enter Date of Birth (DD/MM/YYYY): ");
        String password, confirmPassword;

        while (true) {
            password = getStringInput(s, "Enter Password: ");
            confirmPassword = getStringInput(s, "Confirm Password: ");

            if (password.equals(confirmPassword)) {
                break;
            } else {
                System.out.println("❌ Passwords do not match! Try again.");
            }
        }

        switch (choice) {
            case 1 -> {
                new Client(name, username, password, phone, dateOfBirth);
                System.out.println("✅ Client created successfully!");
            }

            case 2 -> {
                String startTime = getStringInput(s, "Enter Start Time (HH:MM): ");
                String endTime = getStringInput(s, "Enter End Time(HH:MM):  ");

                double salary;
                do {
                    salary = getDoubleInput(s, "Enter Salary: ");
                    if (salary <= 0) {
                        System.out.println("❌ Salary must be positive! Try again.");
                    }
                } while (salary <= 0);

                int licenseNumber;
                while (true) {
                    licenseNumber = getIntInput(s, "Enter License Number: ");
                    if (checkLicenseNumber(licenseNumber)) {
                        break;
                    } else {
                        System.out.println("❌ Doctor already Exists!");
                    }
                }
                new Doctor(name, username, password, phone, dateOfBirth, startTime, endTime, salary, licenseNumber);
                System.out.println("✅ Doctor created successfully!");
            }

            case 3 -> {
                String startTime = getStringInput(s, "Enter Start Time (HH:MM): ");
                String endTime = getStringInput(s, "Enter End Time (HH:MM): ");

                double salary;
                do {
                    salary = getDoubleInput(s, "Enter Salary: ");
                    if (salary <= 0) {
                        System.out.println("❌ Salary must be positive! Try again.");
                    }
                } while (salary <= 0);

                new Admin(name, username, password, phone, dateOfBirth, startTime, endTime, salary);
                System.out.println("✅ Admin created successfully!");
            }

            default ->
                System.out.println("❌ Invalid option!");
        }
    }

}
