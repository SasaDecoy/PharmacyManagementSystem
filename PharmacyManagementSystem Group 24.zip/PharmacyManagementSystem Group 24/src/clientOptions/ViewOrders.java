package clientOptions;

import mainClasses.User;
import mainClasses.Order;
import mainClasses.Option;
import java.util.*;
import static utils.CommonFunctions.*;

public class ViewOrders implements Option {

    @Override
    public String getOption() {
        return "📜 View My Orders";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- My Orders ---");

        ArrayList<Order> myOrders = loadOrdersByCustomerId(u.getId());
        if (myOrders != null) {
            for (Order order : myOrders) {
                order.displayInfo();
            }
        } else {
            System.out.println("❌ No orders found for this ID!");
        }

    }
}
