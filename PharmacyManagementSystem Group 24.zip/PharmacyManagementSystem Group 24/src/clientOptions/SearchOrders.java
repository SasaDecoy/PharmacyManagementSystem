package clientOptions;

import java.time.format.DateTimeFormatter;
import java.util.*;
import mainClasses.*;

public class SearchOrders {

    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d/M/yyyy");

    public int oper(User u, String input, ArrayList<Order> allOrders) {


        for (Order order : allOrders) {
            if ((input.equals(String.valueOf(order.getOrderId())) || (input.equals(order.getOrderDate().format(dateFormatter))))) {
                return order.getOrderId();
            }
        }
        return -1;
    }
}
