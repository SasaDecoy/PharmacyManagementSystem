package clientOptions;

import java.util.*;
import mainClasses.*;
import static utils.CommonFunctions.loadAllUsers;

public class ContactDoctor implements Option {

    @Override
    public String getOption() {
        return "🤙 Contact Doctor";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- Contact Doctor ---");
        ArrayList<User> allDoctors = loadAllUsers("Doctor");

        if (allDoctors.isEmpty()) {
            System.out.println("❌ No doctors at the moment!");
            return;
        }

        for (User doctor : allDoctors) {
            System.out.println("-------------------------------");
            System.out.println("Doctor " + doctor.getName() + " 📞" + doctor.getPhone());
        }
    }

}
