package clientOptions;

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import mainClasses.User;
import static utils.CommonFunctions.*;

public class CancelOrder {

    private static final String ORDERS_FILE = "Data/orders.csv";
    private static final String MEDICINES_FILE = "Data/medicines.csv";

    private int orderId;

    public void oper(User u, int orderId) {
        this.orderId = orderId;
        ArrayList<String> updatedOrders = new ArrayList<>();
        ArrayList<String[]> canceledMedicines = new ArrayList<>();
        boolean canceled = false;
        boolean pending = false;

        try (Scanner scanner = new Scanner(new File(ORDERS_FILE))) {
            if (scanner.hasNextLine()) {
                updatedOrders.add(scanner.nextLine());
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");
                try {

                    int currentOrderId = Integer.parseInt(parts[0]);
                    int customerId = Integer.parseInt(parts[1]);

                    if (currentOrderId == orderId && customerId == u.getId()) {
                        if (parts[6].equals("Canceled")) {
                            canceled = true;
                        } else if (parts[6].equals("Pending")) {
                            pending = true;
                            parts[6] = "Canceled";
                        } else {
                            String[] medicineEntries = parts[2].split("\\|");
                            for (String entry : medicineEntries) {
                                if (!entry.isEmpty()) {
                                    String[] medDetails = entry.split("-");
                                    canceledMedicines.add(medDetails);
                                }
                            }
                            parts[6] = "Canceled";
                        }
                    }
                    updatedOrders.add(String.join(",", parts));
                } catch (NumberFormatException e) {
                    System.out.println("Error➡ " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Error reading orders.csv: " + e.getMessage());
            return;
        }
        if (canceled) {
            JOptionPane.showMessageDialog(null, "❌ Order is already canceled!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!pending) {
            if (restoreMedicineStock(canceledMedicines)) {
                JOptionPane.showMessageDialog(null, "✅ Medicines restored successfully!");
            }
        } else {
            if (pending) {
                JOptionPane.showMessageDialog(null, "✅ Order Canceled successfully!");
            }
        }

        if (writeInFile(ORDERS_FILE, updatedOrders)) {
            System.out.println("✅ Order updated successfully!");
        } else {
            System.out.println("❌ Order couldnt't be updated.");
        }

    }

    private boolean restoreMedicineStock(ArrayList<String[]> canceledMedicines) {
        ArrayList<String> updatedMedicines = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(MEDICINES_FILE))) {
            if (scanner.hasNextLine()) {
                updatedMedicines.add(scanner.nextLine());
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");
                try {

                    int medId = Integer.parseInt(parts[0]);

                    for (String[] medDetails : canceledMedicines) {
                        if (medId == Integer.parseInt(medDetails[0])) {
                            int currentStock = Integer.parseInt(parts[4]);
                            int restoredStock = currentStock + Integer.parseInt(medDetails[1].trim());
                            parts[4] = String.valueOf(restoredStock);
                        }
                    }
                    updatedMedicines.add(String.join(",", parts));
                } catch (NumberFormatException e) {
                    System.out.println("Error➡ " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Error updating medicine stock: " + e.getMessage());
            return false;
        }

        return writeInFile(MEDICINES_FILE, updatedMedicines);

    }
}
