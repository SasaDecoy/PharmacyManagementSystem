package clientOptions;

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import mainClasses.*;
import static utils.CommonFunctions.*;

public class OrderMedicine {

    private static final String MEDICINES_FILE = "Data/medicines.csv";


    public boolean oper(Client u, double paymentAmount, ArrayList<Medicine> selectedMedicines, ArrayList<Integer> quantities, String Total) {
        double amount = paymentAmount;
        double total = 0;
        
        if (selectedMedicines.isEmpty()) {
            JOptionPane.showMessageDialog(null, "❌ No medicines selected.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        total = Double.parseDouble(Total.replace("Total: $", ""));
        if (amount < total) {
            JOptionPane.showMessageDialog(null, "You're order is pending you wont recive your medicine untill you pay the full amount.");
        }

        double changeAmount = amount - total;

        if (changeAmount > 0) {
            JOptionPane.showMessageDialog(null, "💵 You're Change: $" + String.format("%.2f", changeAmount));
        }

        String orderStatus = (amount >= total) ? "Paid" : "Pending";

        if (orderStatus.equals("Paid")) {
            if (updateMedicineStock(selectedMedicines, quantities)) {
                JOptionPane.showMessageDialog(null, "✅ Order placed successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "❌ Order couldn't be placed.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (orderStatus.equals("Pending")) {

        }

        new Order(u.getId(), selectedMedicines, quantities, total, amount, changeAmount, orderStatus);
        return true;
    }

    private boolean updateMedicineStock(ArrayList<Medicine> orderedMedicines, ArrayList<Integer> quantities) {
        ArrayList<String> updatedMedicines = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(MEDICINES_FILE))) {
            if (scanner.hasNextLine()) {
                updatedMedicines.add(scanner.nextLine());
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");
                try {

                    int medId = Integer.parseInt(parts[0]);

                    for (int i = 0; i < orderedMedicines.size(); i++) {
                        if (medId == orderedMedicines.get(i).getId()) {
                            int currentStock = Integer.parseInt(parts[4]);
                            int newStock = currentStock - quantities.get(i);
                            parts[4] = String.valueOf(newStock);
                        }
                    }
                    updatedMedicines.add(String.join(",", parts));

                } catch (NumberFormatException e) {
                    System.out.println("Error➡ " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Error updating medicine stock: " + e.getMessage());
            return false;
        }

        return writeInFile(MEDICINES_FILE, updatedMedicines);

    }
}
