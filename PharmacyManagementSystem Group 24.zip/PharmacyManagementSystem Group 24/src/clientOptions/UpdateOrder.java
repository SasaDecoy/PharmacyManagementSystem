package clientOptions;

import mainClasses.User;
import mainClasses.Medicine;
import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import static utils.CommonFunctions.*;

public class UpdateOrder {

    private static final String ORDERS_FILE = "Data/orders.csv";
    private static final String MEDICINES_FILE = "Data/medicines.csv";
    private double additionalPayment;

    public boolean oper(User u, int orderId, ArrayList<Medicine> selectedMedicines, ArrayList<Integer> quantities, double additionalPayment) {
        this.additionalPayment = additionalPayment;

        ArrayList<String> updatedOrders = new ArrayList<>();
        String[] orderToUpdate = null;
        

        try (Scanner scanner = new Scanner(new File(ORDERS_FILE))) {
            if (scanner.hasNextLine()) {
                updatedOrders.add(scanner.nextLine());
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");

                int currentOrderId = Integer.parseInt(parts[0]);
                int customerId = Integer.parseInt(parts[1]);

                if (currentOrderId == orderId && customerId == u.getId()) {
                    orderToUpdate = parts;
                    continue;
                }

                updatedOrders.add(String.join(",", parts));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "❌ Error reading orders.csv: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (orderToUpdate[6].equals("Canceled")) {
            JOptionPane.showMessageDialog(null, "❌ Order is already canceled can't update.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        addMedicinesToOrder(orderToUpdate, selectedMedicines, quantities);
        updatedOrders.add(String.join(",", orderToUpdate));

        if (writeInFile(ORDERS_FILE, updatedOrders)) {
            JOptionPane.showMessageDialog(null, "✅ Order updated successfully!");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "❌ Order couldn't be updated.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private void addMedicinesToOrder(String[] orderToUpdate, ArrayList<Medicine> selectedMedicines, ArrayList<Integer> quantities) {
        
        for (int i = 0; i < selectedMedicines.size(); i++) {
            if (quantities.get(i) > selectedMedicines.get(i).getStock()) {
                System.out.println("❌ Not enough stock available.");
                return;
            }
        }

        if (!selectedMedicines.isEmpty()) {
            String currentMedicines = orderToUpdate[2];
            double previousTotalAmount = Double.parseDouble(orderToUpdate[3]);
            double previousPaidAmount = Double.parseDouble(orderToUpdate[4]);
            double updateTotalAmount = previousTotalAmount;

            for (int i = 0; i < selectedMedicines.size(); i++) {
                updateTotalAmount += selectedMedicines.get(i).getPrice() * quantities.get(i);
                currentMedicines += selectedMedicines.get(i).getId() + "-" + quantities.get(i) + "|";
            }

            double updateAmountPaid = additionalPayment + previousPaidAmount;
            double remainingBalance = updateAmountPaid - updateTotalAmount;
            orderToUpdate[3] = String.valueOf(updateTotalAmount);
            orderToUpdate[4] = String.valueOf(updateAmountPaid);
            orderToUpdate[6] = (remainingBalance >= 0) ? "Paid" : "Pending";

            if (remainingBalance == 0) {
                JOptionPane.showMessageDialog(null, "✅ Payment complete. Order status updated to 'Paid'.");
                orderToUpdate[5] = String.valueOf(remainingBalance);
            } else if (remainingBalance > 0) {
                JOptionPane.showMessageDialog(null, "✅ Payment complete. Order status updated to 'Paid'. Your change is $" + remainingBalance);
                orderToUpdate[5] = String.valueOf(remainingBalance);
            } else {
                JOptionPane.showMessageDialog(null, "❌ Payment Pending. Order status updated to 'Pending'.");
                JOptionPane.showMessageDialog(null, "🔃 Remaining balance: ️$" + Math.abs(remainingBalance));
                orderToUpdate[5] = String.valueOf(remainingBalance);
            }

            orderToUpdate[2] = currentMedicines;
        } else {
            if (orderToUpdate[6].equals("Pending")) {
                updatePaymentAmount(orderToUpdate);
            } else {
                JOptionPane.showMessageDialog(null, "❌ Order is already complete can't add payment.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

    }

    private void updatePaymentAmount(String[] orderToUpdate) {
        double currentTotal = Double.parseDouble(orderToUpdate[3]);
        double currentPaid = Double.parseDouble(orderToUpdate[4]);
        ArrayList<Medicine> currentMedicines = new ArrayList<>();
        ArrayList<Integer> quantities = new ArrayList<>();

        String[] medicineDetails = orderToUpdate[2].split("\\|");

        for (String medicineDetail : medicineDetails) {
            String[] medicineEntry = medicineDetail.split("-");
            Medicine med = findMedicineByIdOrName(medicineEntry[0]);
            if (med == null) {
                JOptionPane.showMessageDialog(null, "❌ Medicine " + medicineEntry[0] + " no longer exists!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            currentMedicines.add(med);
            quantities.add(Integer.valueOf(medicineEntry[1]));
        }
        if (additionalPayment < 0) {
            JOptionPane.showMessageDialog(null, "❌ Invalid payment amount.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double newAmountPaid = currentPaid + additionalPayment;
        double remainingBalance = currentTotal - newAmountPaid;

        if (remainingBalance <= 0) {
            if (!checkStockAvailability(currentMedicines, quantities)) {
                JOptionPane.showMessageDialog(null, "❌ Cannot complete payment - insufficient stock", "Error", JOptionPane.ERROR_MESSAGE);
                orderToUpdate[6] = "Pending";
                return;
            }

            orderToUpdate[4] = String.valueOf(newAmountPaid);
            orderToUpdate[6] = (remainingBalance <= 0) ? "Paid" : "Pending";

            updateMedicineStock(currentMedicines, quantities);
            JOptionPane.showMessageDialog(null, "✅ Payment complete. Order status updated to 'Paid'.");

            if (remainingBalance < 0) {
                JOptionPane.showMessageDialog(null, "💵 Your change: $" + Math.abs(remainingBalance));
                orderToUpdate[5] = String.valueOf(Math.abs(remainingBalance));
            }
        } else {
            JOptionPane.showMessageDialog(null, "❌ Payment Pending. Remaining balance: $" + remainingBalance, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean checkStockAvailability(ArrayList<Medicine> medicines, ArrayList<Integer> quantities) {
        boolean allInStock = true;

        for (int i = 0; i < medicines.size(); i++) {
            Medicine currentMed = findMedicineById(medicines.get(i).getId());
            if (currentMed.getStock() < quantities.get(i)) {
                JOptionPane.showMessageDialog(null, "❌ Insufficient stock for " + currentMed.getName()
                        + " (Available: " + currentMed.getStock()
                        + ", Needed: " + quantities.get(i) + ")", "Error", JOptionPane.ERROR_MESSAGE);
                allInStock = false;
            }
        }

        return allInStock;
    }

    private boolean updateMedicineStock(ArrayList<Medicine> orderedMedicines, ArrayList<Integer> quantities) {
        ArrayList<String> updatedMedicines = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(MEDICINES_FILE))) {
            if (scanner.hasNextLine()) {
                updatedMedicines.add(scanner.nextLine());
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");
                try {

                    int medId = Integer.parseInt(parts[0]);

                    for (int i = 0; i < orderedMedicines.size(); i++) {
                        if (medId == orderedMedicines.get(i).getId()) {
                            int currentStock = Integer.parseInt(parts[4]);
                            int newStock = currentStock - quantities.get(i);
                            parts[4] = String.valueOf(newStock);
                        }
                    }
                    updatedMedicines.add(String.join(",", parts));

                } catch (NumberFormatException e) {
                    System.out.println("Error➡ " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Error updating medicine stock: " + e.getMessage());
            return false;
        }

        return writeInFile(MEDICINES_FILE, updatedMedicines);

    }
}
