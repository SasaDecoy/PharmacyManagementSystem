package GUI;

import javax.swing.ImageIcon;
import pharmacymanagementsystemconsole.PharmacyManagementSystemGUI;

public class LoginMenu extends javax.swing.JFrame {

    char defaultEchoChar;

    public LoginMenu() {
        initComponents();
        defaultEchoChar = PasswordField.getEchoChar();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LoginPanel = new javax.swing.JPanel();
        Content = new javax.swing.JPanel();
        LoginLogo = new javax.swing.JLabel();
        Username = new javax.swing.JPanel();
        UsernameLbl = new javax.swing.JLabel();
        UsernameField = new javax.swing.JTextField();
        UsernameSeperator = new javax.swing.JSeparator();
        Password = new javax.swing.JPanel();
        PasswordLbl = new javax.swing.JLabel();
        RevealPassword = new javax.swing.JButton();
        PasswordField = new javax.swing.JPasswordField();
        PasswordSeperator = new javax.swing.JSeparator();
        LoginBtn = new javax.swing.JButton();
        Socials = new javax.swing.JPanel();
        SocialsMsg = new javax.swing.JLabel();
        Twitter = new javax.swing.JLabel();
        Instagram = new javax.swing.JLabel();
        Tiktok = new javax.swing.JLabel();
        Register = new javax.swing.JPanel();
        RegisterMsg = new javax.swing.JLabel();
        SignUp = new javax.swing.JLabel();
        Close = new javax.swing.JLabel();
        LoginImg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        LoginPanel.setBackground(java.awt.Color.white);
        LoginPanel.setPreferredSize(new java.awt.Dimension(640, 720));
        LoginPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Content.setBackground(new java.awt.Color(248, 248, 255));
        Content.setOpaque(false);
        Content.setPreferredSize(new java.awt.Dimension(640, 720));
        Content.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LoginLogo.setBackground(new java.awt.Color(51, 51, 255));
        LoginLogo.setFont(new java.awt.Font("Century Gothic", 2, 24)); // NOI18N
        LoginLogo.setForeground(new java.awt.Color(51, 51, 255));
        LoginLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/LoginLogo.jpg"))); // NOI18N
        Content.add(LoginLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, 320, 50));

        Username.setBackground(new java.awt.Color(255, 255, 255));
        Username.setFocusable(false);
        Username.setOpaque(false);

        UsernameLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        UsernameLbl.setForeground(new java.awt.Color(64, 77, 161));
        UsernameLbl.setText("Username");

        UsernameField.setBackground(new java.awt.Color(232, 241, 250));
        UsernameField.setBorder(null);

        javax.swing.GroupLayout UsernameLayout = new javax.swing.GroupLayout(Username);
        Username.setLayout(UsernameLayout);
        UsernameLayout.setHorizontalGroup(
            UsernameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(UsernameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(UsernameLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(UsernameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(UsernameLbl)
                        .addComponent(UsernameField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(UsernameSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        UsernameLayout.setVerticalGroup(
            UsernameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
            .addGroup(UsernameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(UsernameLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(UsernameLbl)
                    .addGap(4, 4, 4)
                    .addComponent(UsernameField, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(2, 2, 2)
                    .addComponent(UsernameSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        Content.add(Username, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, -1, -1));

        Password.setOpaque(false);

        PasswordLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        PasswordLbl.setForeground(new java.awt.Color(64, 77, 161));
        PasswordLbl.setText("Password");

        RevealPassword.setBackground(java.awt.Color.white);
        RevealPassword.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/eyeClosed.png"))); // NOI18N
        RevealPassword.setBorder(null);
        RevealPassword.setContentAreaFilled(false);
        RevealPassword.setFocusPainted(false);
        RevealPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RevealPasswordActionPerformed(evt);
            }
        });

        PasswordField.setBackground(new java.awt.Color(232, 241, 250));
        PasswordField.setBorder(null);

        javax.swing.GroupLayout PasswordLayout = new javax.swing.GroupLayout(Password);
        Password.setLayout(PasswordLayout);
        PasswordLayout.setHorizontalGroup(
            PasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PasswordLayout.createSequentialGroup()
                .addContainerGap(278, Short.MAX_VALUE)
                .addComponent(RevealPassword)
                .addContainerGap())
            .addGroup(PasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PasswordLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(PasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(PasswordLbl)
                        .addComponent(PasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(PasswordSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        PasswordLayout.setVerticalGroup(
            PasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PasswordLayout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addComponent(RevealPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
            .addGroup(PasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PasswordLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(PasswordLbl)
                    .addGap(4, 4, 4)
                    .addComponent(PasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, 0)
                    .addComponent(PasswordSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        Content.add(Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, -1, -1));

        LoginBtn.setBackground(new java.awt.Color(64, 77, 161));
        LoginBtn.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        LoginBtn.setForeground(java.awt.Color.white);
        LoginBtn.setText("Log In");
        LoginBtn.setBorder(null);
        LoginBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginBtnActionPerformed(evt);
            }
        });
        Content.add(LoginBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 430, 300, 40));

        Socials.setOpaque(false);

        SocialsMsg.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        SocialsMsg.setForeground(java.awt.Color.gray);
        SocialsMsg.setText("Follow us on social media");

        Twitter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/twitter.png"))); // NOI18N

        Instagram.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Instagram.png"))); // NOI18N

        Tiktok.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/tiktok.png"))); // NOI18N

        javax.swing.GroupLayout SocialsLayout = new javax.swing.GroupLayout(Socials);
        Socials.setLayout(SocialsLayout);
        SocialsLayout.setHorizontalGroup(
            SocialsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SocialsLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(Twitter)
                .addGap(27, 27, 27)
                .addComponent(Instagram)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addComponent(Tiktok)
                .addGap(23, 23, 23))
            .addGroup(SocialsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(SocialsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(SocialsMsg)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        SocialsLayout.setVerticalGroup(
            SocialsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SocialsLayout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addGroup(SocialsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Twitter)
                    .addComponent(Instagram)
                    .addComponent(Tiktok))
                .addGap(22, 22, 22))
            .addGroup(SocialsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(SocialsLayout.createSequentialGroup()
                    .addGap(0, 6, Short.MAX_VALUE)
                    .addComponent(SocialsMsg)
                    .addGap(0, 50, Short.MAX_VALUE)))
        );

        Content.add(Socials, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 630, 150, 70));

        Register.setOpaque(false);

        RegisterMsg.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        RegisterMsg.setForeground(java.awt.Color.gray);
        RegisterMsg.setText("Don't have an Account?");

        SignUp.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        SignUp.setForeground(new java.awt.Color(51, 51, 255));
        SignUp.setText("Sign up");
        SignUp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SignUpMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SignUpMouseEntered(evt);
            }
        });

        javax.swing.GroupLayout RegisterLayout = new javax.swing.GroupLayout(Register);
        Register.setLayout(RegisterLayout);
        RegisterLayout.setHorizontalGroup(
            RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RegisterLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(RegisterMsg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SignUp)
                .addContainerGap(29, Short.MAX_VALUE))
        );
        RegisterLayout.setVerticalGroup(
            RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RegisterLayout.createSequentialGroup()
                .addContainerGap(10, Short.MAX_VALUE)
                .addGroup(RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RegisterMsg)
                    .addComponent(SignUp))
                .addContainerGap())
        );

        Content.add(Register, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 470, 210, 30));

        Close.setBackground(java.awt.Color.white);
        Close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Close.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Close.jpg"))); // NOI18N
        Close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CloseMouseClicked(evt);
            }
        });
        Content.add(Close, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 10, -1, -1));

        LoginPanel.add(Content, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 0, 668, 720));

        LoginImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/newBg.jpg"))); // NOI18N
        LoginImg.setOpaque(true);
        LoginPanel.add(LoginImg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LoginPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1280, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LoginPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void RevealPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RevealPasswordActionPerformed
        if (PasswordField.getEchoChar() == defaultEchoChar) {
            PasswordField.setEchoChar((char) 0);
            RevealPassword.setIcon(new ImageIcon(getClass().getResource("/images/openEyes.png")));
        } else {
            PasswordField.setEchoChar(defaultEchoChar);
            RevealPassword.setIcon(new ImageIcon(getClass().getResource("/images/eyeClosed.png")));
        }
    }//GEN-LAST:event_RevealPasswordActionPerformed

    private void LoginBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginBtnActionPerformed

        String username = UsernameField.getText();
        String password = new String(PasswordField.getPassword());
        PharmacyManagementSystemGUI.processLogin(username, password, this);

    }//GEN-LAST:event_LoginBtnActionPerformed

    private void SignUpMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SignUpMouseEntered
        SignUp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
    }//GEN-LAST:event_SignUpMouseEntered

    private void SignUpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SignUpMouseClicked
        new RegisterMenu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_SignUpMouseClicked

    private void CloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseMouseClicked
        this.dispose();
    }//GEN-LAST:event_CloseMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Close;
    private javax.swing.JPanel Content;
    private javax.swing.JLabel Instagram;
    private javax.swing.JButton LoginBtn;
    private javax.swing.JLabel LoginImg;
    private javax.swing.JLabel LoginLogo;
    private javax.swing.JPanel LoginPanel;
    private javax.swing.JPanel Password;
    private javax.swing.JPasswordField PasswordField;
    private javax.swing.JLabel PasswordLbl;
    private javax.swing.JSeparator PasswordSeperator;
    private javax.swing.JPanel Register;
    private javax.swing.JLabel RegisterMsg;
    private javax.swing.JButton RevealPassword;
    private javax.swing.JLabel SignUp;
    private javax.swing.JPanel Socials;
    private javax.swing.JLabel SocialsMsg;
    private javax.swing.JLabel Tiktok;
    private javax.swing.JLabel Twitter;
    private javax.swing.JPanel Username;
    private javax.swing.JTextField UsernameField;
    private javax.swing.JLabel UsernameLbl;
    private javax.swing.JSeparator UsernameSeperator;
    // End of variables declaration//GEN-END:variables
}
