package GUI.components;

import java.awt.Color;
import java.net.MalformedURLException;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import mainClasses.Medicine;
import mainClasses.User;

public class MedicineCard extends javax.swing.JPanel {

    private final Medicine med;
    private final DefaultTableModel cartModel;
    private final JLabel TotalLbl;
    private final User u;

    public MedicineCard(Medicine med, DefaultTableModel cartModel, JLabel TotalLbl, User u) throws MalformedURLException {
        this.med = med;
        this.u = u;
        this.cartModel = cartModel;
        this.TotalLbl = TotalLbl;
        initComponents();
    }

    private void adjustQuantity(int delta) {
        ArrayList<Integer> rows = new ArrayList<>();
        boolean hasLocked = false;
        for (int i = 0; i < cartModel.getRowCount(); i++) {
            if (cartModel.getValueAt(i, 0).equals(med.getName())) {
                rows.add(i);
                if (cartModel.getValueAt(i, 3).equals("🔒")) {
                    hasLocked = true;
                }
            }
        }

        boolean isPrescribed = true;
        ArrayList<String> prescribedClients = med.getPrescribed();

        if (prescribedClients != null) {
            isPrescribed = false;
            for (String id : prescribedClients) {
                if (id.equals(String.valueOf(u.getId()))) {
                    isPrescribed = true;
                }
            }
        }
        if (!isPrescribed) {
            JOptionPane.showMessageDialog(null, "❌ Sorry you are not eligible to order this medicine", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else {

            if (delta == -1) {
                handleMinusAction(rows, hasLocked);
            } else {
                handlePlusAction(rows);
            }

            updateTotal();
            updateQuantityDisplay();
        }
    }

    private void handleMinusAction(ArrayList<Integer> rows, boolean hasLocked) {
        int lastRemovableRow = -1;
        int removableQty = 0;

        for (int i = rows.size() - 1; i >= 0; i--) {
            int row = rows.get(i);
            if (cartModel.getValueAt(row, 3).equals("❌")) {
                lastRemovableRow = row;
                removableQty = (int) cartModel.getValueAt(row, 1);
                break;
            }
        }

        if (lastRemovableRow == -1) {
            if (hasLocked) {
                JOptionPane.showMessageDialog(this, "Cannot remove original order items!");
            }
            return;
        }

        if (removableQty > 1) {
            int newQty = removableQty - 1;
            cartModel.setValueAt(newQty, lastRemovableRow, 1);
            cartModel.setValueAt(med.getPrice() * newQty, lastRemovableRow, 2);
        } else {
            cartModel.removeRow(lastRemovableRow);
        }
    }

    private void handlePlusAction(ArrayList<Integer> rows) {

        int totalQty = 0;
        for (int row : rows) {
            totalQty += (int) cartModel.getValueAt(row, 1);
        }

        if (totalQty >= med.getStock()) {
            JOptionPane.showMessageDialog(this, "Not enough stock!");
            return;
        }

        int lastRemovableRow = -1;
        for (int i = rows.size() - 1; i >= 0; i--) {
            int row = rows.get(i);
            if (cartModel.getValueAt(row, 3).equals("❌")) {
                lastRemovableRow = row;
                break;
            }
        }

        if (lastRemovableRow != -1) {
            int newQty = (int) cartModel.getValueAt(lastRemovableRow, 1) + 1;
            cartModel.setValueAt(newQty, lastRemovableRow, 1);
            cartModel.setValueAt(med.getPrice() * newQty, lastRemovableRow, 2);
        } else {
            cartModel.addRow(new Object[]{
                med.getName(),
                1,
                med.getPrice(),
                "❌"
            });
        }
    }

    private void updateQuantityDisplay() {
        int totalQty = 0;
        for (int i = 0; i < cartModel.getRowCount(); i++) {
            if (cartModel.getValueAt(i, 0).equals(med.getName())) {
                totalQty += (int) cartModel.getValueAt(i, 1);
            }
        }
        NoOfMed.setText(String.valueOf(totalQty));
    }

    private void updateTotal() {
        double total = 0;
        for (int i = 0; i < cartModel.getRowCount(); i++) {
            total += (double) cartModel.getValueAt(i, 2);
        }
        TotalLbl.setText(String.format("Total: $%.2f", total));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CardPanel = new GUI.components.PanelBorder();
        Name = new javax.swing.JLabel();
        AvailableStock = new javax.swing.JLabel();
        BreakLine = new javax.swing.JSeparator();
        MedImg = new javax.swing.JLabel();
        MedComposition = new javax.swing.JLabel();
        OrderPanel = new javax.swing.JPanel();
        MinusPanel = new GUI.components.PanelBorder();
        MinusSign = new javax.swing.JLabel();
        NoOfMed = new javax.swing.JLabel();
        PlusPanel = new GUI.components.PanelBorder();
        PlusSign = new javax.swing.JLabel();

        setBackground(new java.awt.Color(64, 77, 161));
        setForeground(new java.awt.Color(64, 77, 161));

        CardPanel.setBackground(new java.awt.Color(248, 248, 248));
        CardPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Name.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        Name.setText(med.getName());
        CardPanel.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 10, 310, 20));

        AvailableStock.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        AvailableStock.setText("Available Stock: " + med.getStock());
        CardPanel.add(AvailableStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 310, -1));

        BreakLine.setBackground(new java.awt.Color(138, 158, 221));
        BreakLine.setForeground(new java.awt.Color(138, 158, 221));
        CardPanel.add(BreakLine, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 115, 680, 14));

        MedImg.setIcon(new javax.swing.JLabel() {
            public javax.swing.Icon getIcon() {
                try {
                    return new javax.swing.ImageIcon(
                        new java.net.URL("")
                    );
                } catch (java.net.MalformedURLException e) {
                }
                return null;
            }
        }.getIcon());
        CardPanel.add(MedImg, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 6, 100, 100));

        MedComposition.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        MedComposition.setText("Composition: " + med.getComposition());
        CardPanel.add(MedComposition, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, 390, -1));

        OrderPanel.setOpaque(false);
        OrderPanel.setLayout(new java.awt.GridLayout(1, 0));

        MinusPanel.setBackground(new java.awt.Color(232, 241, 250));

        MinusSign.setBackground(new java.awt.Color(232, 241, 250));
        MinusSign.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MinusSign.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/minus.png"))); // NOI18N
        MinusSign.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        MinusSign.setFocusable(false);
        MinusSign.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MinusSignMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                MinusSignMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                MinusSignMouseExited(evt);
            }
        });

        javax.swing.GroupLayout MinusPanelLayout = new javax.swing.GroupLayout(MinusPanel);
        MinusPanel.setLayout(MinusPanelLayout);
        MinusPanelLayout.setHorizontalGroup(
            MinusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MinusSign, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );
        MinusPanelLayout.setVerticalGroup(
            MinusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MinusSign, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        OrderPanel.add(MinusPanel);

        NoOfMed.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        NoOfMed.setForeground(new java.awt.Color(64, 77, 161));
        NoOfMed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        NoOfMed.setText("0");
        OrderPanel.add(NoOfMed);

        PlusPanel.setBackground(new java.awt.Color(232, 241, 250));

        PlusSign.setBackground(new java.awt.Color(232, 241, 250));
        PlusSign.setForeground(java.awt.Color.black);
        PlusSign.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        PlusSign.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/plus.png"))); // NOI18N
        PlusSign.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PlusSignMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PlusSignMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PlusSignMouseExited(evt);
            }
        });

        javax.swing.GroupLayout PlusPanelLayout = new javax.swing.GroupLayout(PlusPanel);
        PlusPanel.setLayout(PlusPanelLayout);
        PlusPanelLayout.setHorizontalGroup(
            PlusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PlusSign, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );
        PlusPanelLayout.setVerticalGroup(
            PlusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PlusSign, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        OrderPanel.add(PlusPanel);

        CardPanel.add(OrderPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 40, 120, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(CardPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 681, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(CardPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void PlusSignMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PlusSignMouseEntered
        PlusPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PlusPanel.setBackground(new Color(123, 166, 216));
    }//GEN-LAST:event_PlusSignMouseEntered

    private void PlusSignMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PlusSignMouseExited
        PlusPanel.setBackground(new Color(232, 241, 250));
    }//GEN-LAST:event_PlusSignMouseExited

    private void PlusSignMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PlusSignMouseClicked
        adjustQuantity(1);
    }//GEN-LAST:event_PlusSignMouseClicked

    private void MinusSignMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MinusSignMouseClicked
        adjustQuantity(-1);
    }//GEN-LAST:event_MinusSignMouseClicked

    private void MinusSignMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MinusSignMouseEntered
        MinusSign.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MinusPanel.setBackground(new Color(123, 166, 216));
    }//GEN-LAST:event_MinusSignMouseEntered

    private void MinusSignMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MinusSignMouseExited
        MinusPanel.setBackground(new Color(232, 241, 250));
    }//GEN-LAST:event_MinusSignMouseExited


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AvailableStock;
    private javax.swing.JSeparator BreakLine;
    private GUI.components.PanelBorder CardPanel;
    private javax.swing.JLabel MedComposition;
    private javax.swing.JLabel MedImg;
    private GUI.components.PanelBorder MinusPanel;
    private javax.swing.JLabel MinusSign;
    private javax.swing.JLabel Name;
    private javax.swing.JLabel NoOfMed;
    private javax.swing.JPanel OrderPanel;
    private GUI.components.PanelBorder PlusPanel;
    private javax.swing.JLabel PlusSign;
    // End of variables declaration//GEN-END:variables
}
