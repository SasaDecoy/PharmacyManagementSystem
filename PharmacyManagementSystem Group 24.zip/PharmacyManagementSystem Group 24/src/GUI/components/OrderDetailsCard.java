package GUI.components;

import java.util.ArrayList;
import mainClasses.Medicine;
import mainClasses.Order;

public class OrderDetailsCard extends javax.swing.JPanel {

    private final Order order;
    public OrderDetailsCard(Order order) {
        this.order = order;
        initComponents();
        setupOrderDetails();
    }
    
    private void setupOrderDetails()
    {
        ArrayList<Medicine> orderMedicines = order.getMedicines();
        for(int i = 0 ; i < orderMedicines.size() ; i++)
        {
            OrderDetailTextCard card = new OrderDetailTextCard(orderMedicines.get(i).getName(), order.getQuantities().get(i), order.getQuantities().get(i) * orderMedicines.get(i).getPrice());
            OrderDetailsListPanel.add(card);
        }
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ContentPanel = new javax.swing.JPanel();
        OrderNo = new javax.swing.JLabel();
        OrderDetailsHeader = new javax.swing.JPanel();
        HeaderSeperator = new javax.swing.JSeparator();
        QuantityLbl = new javax.swing.JLabel();
        DescriptionLbl = new javax.swing.JLabel();
        SubTotalLbl = new javax.swing.JLabel();
        OrderDetailsList = new javax.swing.JScrollPane();
        OrderDetailsListPanel = new javax.swing.JPanel();
        TotalPanel = new javax.swing.JPanel();
        Seperator1 = new javax.swing.JSeparator();
        TotalLbl = new javax.swing.JLabel();
        StatusLbl = new javax.swing.JLabel();
        ChangeLbl = new javax.swing.JLabel();
        DateLbl = new javax.swing.JLabel();
        Total = new javax.swing.JLabel();
        Seperator2 = new javax.swing.JSeparator();
        BG = new javax.swing.JLabel();

        ContentPanel.setBackground(java.awt.Color.white);
        ContentPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        OrderNo.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        OrderNo.setForeground(java.awt.Color.white);
        OrderNo.setText("Order: #" + order.getOrderId());
        ContentPanel.add(OrderNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, -1, -1));

        OrderDetailsHeader.setOpaque(false);

        HeaderSeperator.setForeground(new java.awt.Color(64, 77, 161));

        QuantityLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        QuantityLbl.setForeground(new java.awt.Color(64, 77, 161));
        QuantityLbl.setText("QUANTITY");

        DescriptionLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        DescriptionLbl.setForeground(new java.awt.Color(64, 77, 161));
        DescriptionLbl.setText("DESCRIPTION");

        SubTotalLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        SubTotalLbl.setForeground(new java.awt.Color(64, 77, 161));
        SubTotalLbl.setText("SUBTOTAL");

        javax.swing.GroupLayout OrderDetailsHeaderLayout = new javax.swing.GroupLayout(OrderDetailsHeader);
        OrderDetailsHeader.setLayout(OrderDetailsHeaderLayout);
        OrderDetailsHeaderLayout.setHorizontalGroup(
            OrderDetailsHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 355, Short.MAX_VALUE)
            .addGroup(OrderDetailsHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(OrderDetailsHeaderLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(OrderDetailsHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(HeaderSeperator)
                        .addGroup(OrderDetailsHeaderLayout.createSequentialGroup()
                            .addComponent(DescriptionLbl)
                            .addGap(117, 117, 117)
                            .addComponent(QuantityLbl)
                            .addGap(27, 27, 27)
                            .addComponent(SubTotalLbl)))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        OrderDetailsHeaderLayout.setVerticalGroup(
            OrderDetailsHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
            .addGroup(OrderDetailsHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(OrderDetailsHeaderLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(OrderDetailsHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(DescriptionLbl)
                        .addComponent(QuantityLbl)
                        .addComponent(SubTotalLbl))
                    .addGap(1, 1, 1)
                    .addComponent(HeaderSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        ContentPanel.add(OrderDetailsHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, 20));

        OrderDetailsList.setBackground(java.awt.Color.white);
        OrderDetailsList.setBorder(null);

        OrderDetailsListPanel.setBackground(java.awt.Color.white);
        OrderDetailsListPanel.setLayout(new javax.swing.BoxLayout(OrderDetailsListPanel, javax.swing.BoxLayout.PAGE_AXIS));
        OrderDetailsList.setViewportView(OrderDetailsListPanel);

        ContentPanel.add(OrderDetailsList, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 370, 180));

        TotalPanel.setOpaque(false);
        TotalPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Seperator1.setForeground(new java.awt.Color(64, 77, 161));
        TotalPanel.add(Seperator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 350, 10));

        TotalLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        TotalLbl.setForeground(new java.awt.Color(64, 77, 161));
        TotalLbl.setText("TOTAL");
        TotalPanel.add(TotalLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 0, -1, -1));

        StatusLbl.setText("Order Status: " + order.getOrderStatus());
        TotalPanel.add(StatusLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        ChangeLbl.setText("Change Amount: $" + order.getChangeAmount());
        TotalPanel.add(ChangeLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        DateLbl.setText("Date: " + order.getOrderDate());
        TotalPanel.add(DateLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        Total.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        Total.setForeground(new java.awt.Color(64, 77, 161));
        Total.setText("$" + order.getTotalPrice());
        TotalPanel.add(Total, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 40, -1, -1));

        Seperator2.setForeground(new java.awt.Color(64, 77, 161));
        TotalPanel.add(Seperator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 350, 10));

        ContentPanel.add(TotalPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, 380, 90));

        BG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/OrderRecieptBG.png"))); // NOI18N
        ContentPanel.add(BG, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 556));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ContentPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ContentPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BG;
    private javax.swing.JLabel ChangeLbl;
    private javax.swing.JPanel ContentPanel;
    private javax.swing.JLabel DateLbl;
    private javax.swing.JLabel DescriptionLbl;
    private javax.swing.JSeparator HeaderSeperator;
    private javax.swing.JPanel OrderDetailsHeader;
    private javax.swing.JScrollPane OrderDetailsList;
    private javax.swing.JPanel OrderDetailsListPanel;
    private javax.swing.JLabel OrderNo;
    private javax.swing.JLabel QuantityLbl;
    private javax.swing.JSeparator Seperator1;
    private javax.swing.JSeparator Seperator2;
    private javax.swing.JLabel StatusLbl;
    private javax.swing.JLabel SubTotalLbl;
    private javax.swing.JLabel Total;
    private javax.swing.JLabel TotalLbl;
    private javax.swing.JPanel TotalPanel;
    // End of variables declaration//GEN-END:variables
}
