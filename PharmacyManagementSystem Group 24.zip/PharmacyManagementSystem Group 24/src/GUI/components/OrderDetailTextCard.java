package GUI.components;

public class OrderDetailTextCard extends javax.swing.JPanel {

    private final String name;
    private final double subTotal;
    private final int quantity;

    public OrderDetailTextCard(String name, int quantity, double subTotal) {
        this.name = name;
        this.quantity = quantity;
        this.subTotal = subTotal;

        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        NameLbl = new javax.swing.JLabel();
        SubTotalLbl = new javax.swing.JLabel();
        QuantityLbl = new javax.swing.JLabel();

        setOpaque(false);

        NameLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        NameLbl.setText(name);

        SubTotalLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        SubTotalLbl.setText("$" + String.valueOf(subTotal));

        QuantityLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        QuantityLbl.setText(String.valueOf(quantity));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(NameLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(QuantityLbl)
                .addGap(59, 59, 59)
                .addComponent(SubTotalLbl)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NameLbl)
                    .addComponent(SubTotalLbl)
                    .addComponent(QuantityLbl))
                .addContainerGap(17, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel NameLbl;
    private javax.swing.JLabel QuantityLbl;
    private javax.swing.JLabel SubTotalLbl;
    // End of variables declaration//GEN-END:variables
}
