package GUI.components;

import mainClasses.Order;

public class OrderCard extends javax.swing.JPanel {

    private static Order order;

    public OrderCard(Order order) {
        this.order = order;
        initComponents();
    }

    public Order getOrder() {
        return order;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        OrderCardPanel = new GUI.components.PanelBorder();
        OrderID = new javax.swing.JLabel();
        TotalAmount = new javax.swing.JLabel();
        OrderDate = new javax.swing.JLabel();

        OrderCardPanel.setBackground(java.awt.Color.white);
        OrderCardPanel.setPreferredSize(new java.awt.Dimension(109, 109));

        OrderID.setForeground(java.awt.Color.black);
        OrderID.setText("OrderNo: #" + order.getOrderId());

        TotalAmount.setForeground(java.awt.Color.black);
        TotalAmount.setText("Total Amount: $" + order.getTotalPrice());

        OrderDate.setForeground(java.awt.Color.black);
        OrderDate.setText("Date: " + order.getOrderDate());

        javax.swing.GroupLayout OrderCardPanelLayout = new javax.swing.GroupLayout(OrderCardPanel);
        OrderCardPanel.setLayout(OrderCardPanelLayout);
        OrderCardPanelLayout.setHorizontalGroup(
            OrderCardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(OrderCardPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(OrderCardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(OrderID)
                    .addComponent(TotalAmount)
                    .addComponent(OrderDate))
                .addContainerGap(78, Short.MAX_VALUE))
        );
        OrderCardPanelLayout.setVerticalGroup(
            OrderCardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(OrderCardPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(OrderID)
                .addGap(18, 18, 18)
                .addComponent(TotalAmount)
                .addGap(18, 18, 18)
                .addComponent(OrderDate)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(OrderCardPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(OrderCardPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public GUI.components.PanelBorder OrderCardPanel;
    private javax.swing.JLabel OrderDate;
    private javax.swing.JLabel OrderID;
    private javax.swing.JLabel TotalAmount;
    // End of variables declaration//GEN-END:variables
}
