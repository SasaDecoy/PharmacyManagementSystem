package GUI;

import GUI.ClientGUI.OrderMedicineGUI;
import GUI.ClientGUI.UpdateOrderGUI;
import GUI.ClientGUI.ViewOrders;
import java.awt.Color;
import java.net.MalformedURLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import mainClasses.Client;

public class ClientMainMenu extends javax.swing.JFrame {

    private static Client u;

    public ClientMainMenu(Client u) {
        this.u = u;
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ClientMainMenu = new javax.swing.JPanel();
        ButtonsPanel = new javax.swing.JPanel();
        OrderMedicinePanel = new GUI.components.PanelBorder();
        OrderMedicineImg = new javax.swing.JLabel();
        OrderMedicineLbl = new javax.swing.JLabel();
        UpdateOrderPanel = new GUI.components.PanelBorder();
        UpdateOrderImg = new javax.swing.JLabel();
        UpdateOrderLbl = new javax.swing.JLabel();
        ViewOrdersPanel = new GUI.components.PanelBorder();
        ViewOrderImg = new javax.swing.JLabel();
        ViewOrderLbl = new javax.swing.JLabel();
        ContactDoctorPanel = new GUI.components.PanelBorder();
        ContactDoctorImg = new javax.swing.JLabel();
        ContactDoctorLbl = new javax.swing.JLabel();
        Logout = new javax.swing.JLabel();
        Close = new javax.swing.JLabel();
        ClientMainMenuLbl = new javax.swing.JLabel();
        ClientMainMenuBG = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(176, 235, 255));
        setUndecorated(true);
        setResizable(false);

        ClientMainMenu.setBackground(new java.awt.Color(248, 248, 248));
        ClientMainMenu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ButtonsPanel.setInheritsPopupMenu(true);
        ButtonsPanel.setOpaque(false);
        ButtonsPanel.setLayout(new java.awt.GridLayout(2, 2, 20, 20));

        OrderMedicinePanel.setBackground(new java.awt.Color(64, 77, 161));
        OrderMedicinePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OrderMedicinePanelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                OrderMedicinePanelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                OrderMedicinePanelMouseExited(evt);
            }
        });

        OrderMedicineImg.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        OrderMedicineImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cart.png"))); // NOI18N

        OrderMedicineLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        OrderMedicineLbl.setForeground(java.awt.Color.white);
        OrderMedicineLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        OrderMedicineLbl.setText("Order Medicine");

        javax.swing.GroupLayout OrderMedicinePanelLayout = new javax.swing.GroupLayout(OrderMedicinePanel);
        OrderMedicinePanel.setLayout(OrderMedicinePanelLayout);
        OrderMedicinePanelLayout.setHorizontalGroup(
            OrderMedicinePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 245, Short.MAX_VALUE)
            .addGroup(OrderMedicinePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(OrderMedicinePanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(OrderMedicinePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(OrderMedicinePanelLayout.createSequentialGroup()
                            .addGap(20, 20, 20)
                            .addComponent(OrderMedicineImg, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(OrderMedicineLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        OrderMedicinePanelLayout.setVerticalGroup(
            OrderMedicinePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 140, Short.MAX_VALUE)
            .addGroup(OrderMedicinePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(OrderMedicinePanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(OrderMedicineImg, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, 0)
                    .addComponent(OrderMedicineLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        ButtonsPanel.add(OrderMedicinePanel);

        UpdateOrderPanel.setBackground(new java.awt.Color(64, 77, 161));
        UpdateOrderPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateOrderPanelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                UpdateOrderPanelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                UpdateOrderPanelMouseExited(evt);
            }
        });

        UpdateOrderImg.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        UpdateOrderImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/modification.png"))); // NOI18N

        UpdateOrderLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        UpdateOrderLbl.setForeground(java.awt.Color.white);
        UpdateOrderLbl.setText("Update Order");

        javax.swing.GroupLayout UpdateOrderPanelLayout = new javax.swing.GroupLayout(UpdateOrderPanel);
        UpdateOrderPanel.setLayout(UpdateOrderPanelLayout);
        UpdateOrderPanelLayout.setHorizontalGroup(
            UpdateOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 245, Short.MAX_VALUE)
            .addGroup(UpdateOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(UpdateOrderPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(UpdateOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(UpdateOrderPanelLayout.createSequentialGroup()
                            .addGap(20, 20, 20)
                            .addComponent(UpdateOrderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(UpdateOrderLbl))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        UpdateOrderPanelLayout.setVerticalGroup(
            UpdateOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 140, Short.MAX_VALUE)
            .addGroup(UpdateOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(UpdateOrderPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(UpdateOrderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(10, 10, 10)
                    .addComponent(UpdateOrderLbl)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        ButtonsPanel.add(UpdateOrderPanel);

        ViewOrdersPanel.setBackground(new java.awt.Color(64, 77, 161));
        ViewOrdersPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ViewOrdersPanelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ViewOrdersPanelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ViewOrdersPanelMouseExited(evt);
            }
        });

        ViewOrderImg.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewOrderImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/reciept.png"))); // NOI18N

        ViewOrderLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        ViewOrderLbl.setForeground(java.awt.Color.white);
        ViewOrderLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewOrderLbl.setText("View Orders");

        javax.swing.GroupLayout ViewOrdersPanelLayout = new javax.swing.GroupLayout(ViewOrdersPanel);
        ViewOrdersPanel.setLayout(ViewOrdersPanelLayout);
        ViewOrdersPanelLayout.setHorizontalGroup(
            ViewOrdersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 245, Short.MAX_VALUE)
            .addGroup(ViewOrdersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(ViewOrdersPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(ViewOrdersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(ViewOrdersPanelLayout.createSequentialGroup()
                            .addGap(20, 20, 20)
                            .addComponent(ViewOrderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(ViewOrderLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        ViewOrdersPanelLayout.setVerticalGroup(
            ViewOrdersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 140, Short.MAX_VALUE)
            .addGroup(ViewOrdersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(ViewOrdersPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ViewOrderImg, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, 0)
                    .addComponent(ViewOrderLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        ButtonsPanel.add(ViewOrdersPanel);

        ContactDoctorPanel.setBackground(new java.awt.Color(64, 77, 161));
        ContactDoctorPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ContactDoctorPanelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ContactDoctorPanelMouseExited(evt);
            }
        });

        ContactDoctorImg.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ContactDoctorImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/phone.png"))); // NOI18N

        ContactDoctorLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        ContactDoctorLbl.setForeground(java.awt.Color.white);
        ContactDoctorLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ContactDoctorLbl.setText("Contact Doctor");

        javax.swing.GroupLayout ContactDoctorPanelLayout = new javax.swing.GroupLayout(ContactDoctorPanel);
        ContactDoctorPanel.setLayout(ContactDoctorPanelLayout);
        ContactDoctorPanelLayout.setHorizontalGroup(
            ContactDoctorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 245, Short.MAX_VALUE)
            .addGroup(ContactDoctorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(ContactDoctorPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(ContactDoctorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(ContactDoctorPanelLayout.createSequentialGroup()
                            .addGap(20, 20, 20)
                            .addComponent(ContactDoctorImg, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(ContactDoctorLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        ContactDoctorPanelLayout.setVerticalGroup(
            ContactDoctorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 140, Short.MAX_VALUE)
            .addGroup(ContactDoctorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(ContactDoctorPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ContactDoctorImg, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, 0)
                    .addComponent(ContactDoctorLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        ButtonsPanel.add(ContactDoctorPanel);

        ClientMainMenu.add(ButtonsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 210, 510, 300));

        Logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logout.png"))); // NOI18N
        Logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutMouseClicked(evt);
            }
        });
        ClientMainMenu.add(Logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 20, 20, 20));

        Close.setBackground(java.awt.Color.white);
        Close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Close.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Close.jpg"))); // NOI18N
        Close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CloseMouseClicked(evt);
            }
        });
        ClientMainMenu.add(Close, new org.netbeans.lib.awtextra.AbsoluteConstraints(1246, 20, 20, 20));

        ClientMainMenuLbl.setFont(new java.awt.Font("Montserrat-Alt1 SemBd", 0, 36)); // NOI18N
        ClientMainMenuLbl.setForeground(new java.awt.Color(64, 77, 161));
        ClientMainMenuLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ClientMainMenuLogo.png"))); // NOI18N
        ClientMainMenu.add(ClientMainMenuLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 380, 40));

        ClientMainMenuBG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ClientMainMenuBG.png"))); // NOI18N
        ClientMainMenu.add(ClientMainMenuBG, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));
        ClientMainMenuBG.getAccessibleContext().setAccessibleDescription("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(ClientMainMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 1280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(ClientMainMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseMouseClicked
        this.dispose();
    }//GEN-LAST:event_CloseMouseClicked

    private void LogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseClicked
        new LoginMenu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_LogoutMouseClicked

    private void OrderMedicinePanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OrderMedicinePanelMouseEntered
        OrderMedicinePanel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        OrderMedicinePanel.setBackground(new Color(41, 45, 107));
    }//GEN-LAST:event_OrderMedicinePanelMouseEntered

    private void OrderMedicinePanelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OrderMedicinePanelMouseExited
        OrderMedicinePanel.setBackground(new Color(64, 77, 161));
    }//GEN-LAST:event_OrderMedicinePanelMouseExited

    private void UpdateOrderPanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateOrderPanelMouseEntered
        UpdateOrderPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        UpdateOrderPanel.setBackground(new Color(41, 45, 107));
    }//GEN-LAST:event_UpdateOrderPanelMouseEntered

    private void UpdateOrderPanelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateOrderPanelMouseExited
        UpdateOrderPanel.setBackground(new Color(64, 77, 161));
    }//GEN-LAST:event_UpdateOrderPanelMouseExited

    private void ViewOrdersPanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ViewOrdersPanelMouseEntered
        ViewOrdersPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ViewOrdersPanel.setBackground(new Color(41, 45, 107));
    }//GEN-LAST:event_ViewOrdersPanelMouseEntered

    private void ViewOrdersPanelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ViewOrdersPanelMouseExited
        ViewOrdersPanel.setBackground(new Color(64, 77, 161));
    }//GEN-LAST:event_ViewOrdersPanelMouseExited

    private void ContactDoctorPanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ContactDoctorPanelMouseEntered
        ContactDoctorPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ContactDoctorPanel.setBackground(new Color(41, 45, 107));
    }//GEN-LAST:event_ContactDoctorPanelMouseEntered

    private void ContactDoctorPanelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ContactDoctorPanelMouseExited
        ContactDoctorPanel.setBackground(new Color(64, 77, 161));
    }//GEN-LAST:event_ContactDoctorPanelMouseExited

    private void OrderMedicinePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OrderMedicinePanelMouseClicked
        try {
            new OrderMedicineGUI(u).setVisible(true);
        } catch (MalformedURLException ex) {
            Logger.getLogger(ClientMainMenu.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
    }//GEN-LAST:event_OrderMedicinePanelMouseClicked

    private void UpdateOrderPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateOrderPanelMouseClicked
        try {
            new UpdateOrderGUI(u).setVisible(true);
        } catch (MalformedURLException ex) {
            Logger.getLogger(ClientMainMenu.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
    }//GEN-LAST:event_UpdateOrderPanelMouseClicked

    private void ViewOrdersPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ViewOrdersPanelMouseClicked
        new ViewOrders(u).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ViewOrdersPanelMouseClicked

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClientMainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClientMainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClientMainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClientMainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientMainMenu(u).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ButtonsPanel;
    private javax.swing.JPanel ClientMainMenu;
    private javax.swing.JLabel ClientMainMenuBG;
    private javax.swing.JLabel ClientMainMenuLbl;
    private javax.swing.JLabel Close;
    private javax.swing.JLabel ContactDoctorImg;
    private javax.swing.JLabel ContactDoctorLbl;
    private GUI.components.PanelBorder ContactDoctorPanel;
    private javax.swing.JLabel Logout;
    private javax.swing.JLabel OrderMedicineImg;
    private javax.swing.JLabel OrderMedicineLbl;
    private GUI.components.PanelBorder OrderMedicinePanel;
    private javax.swing.JLabel UpdateOrderImg;
    private javax.swing.JLabel UpdateOrderLbl;
    private GUI.components.PanelBorder UpdateOrderPanel;
    private javax.swing.JLabel ViewOrderImg;
    private javax.swing.JLabel ViewOrderLbl;
    private GUI.components.PanelBorder ViewOrdersPanel;
    // End of variables declaration//GEN-END:variables
}
