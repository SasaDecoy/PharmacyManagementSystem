package GUI.ClientGUI;

import GUI.ClientMainMenu;
import GUI.LoginMenu;
import GUI.components.MedicineCard;
import GUI.components.OrderCard;
import clientOptions.CancelOrder;
import clientOptions.UpdateOrder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import mainClasses.*;
import static utils.CommonFunctions.*;

public class UpdateOrderGUI extends javax.swing.JFrame {

    private static Client u;
    DefaultTableModel cartModel;
    ArrayList<Medicine> allMedicine = loadMedicines();
    ArrayList<Order> allOrders;
    private Order selectedOrder;
    private int originalItemsCount = 0;

    public UpdateOrderGUI(Client u) throws MalformedURLException {
        this.u = u;
        allOrders = loadOrdersByCustomerId(u.getId());
        initComponents();
        setupOrderCards();
        disableOrderControls();

        cartModel = new DefaultTableModel(
                new Object[]{"Medicine", "Quantity", "Price", ""}, 0
        );
        tblCart.setModel(cartModel);
        tblCart.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int column = tblCart.columnAtPoint(e.getPoint());
                int row = tblCart.rowAtPoint(e.getPoint());

                if (column == 3 && row >= originalItemsCount) {
                    cartModel.removeRow(row);
                    updateTotal();
                }
            }
        });

        for (Medicine med : allMedicine) {
            MedicineCard card = new MedicineCard(med, cartModel, TotalLbl, u);
            MedicineListPanel.add(card);
        }

    }

    private void setupOrderCards() {
        OrderListPanel.removeAll();
        for (Order order : allOrders) {
            if (!order.getOrderStatus().equals("Canceled")) {
                final Order currentOrder = order;

                OrderCard card = new OrderCard(currentOrder);

                card.OrderCardPanel.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        selectedOrder = currentOrder;
                        loadOrderIntoCart();
                        updatePaymentDisplay();
                        enableOrderControls();
                    }
                });
                OrderListPanel.add(card);
            }
        }
        OrderListPanel.revalidate();
        OrderListPanel.repaint();

    }

    private void updateTotal() {
        double total = 0;
        for (int i = 0; i < cartModel.getRowCount(); i++) {
            total += (double) cartModel.getValueAt(i, 2);
        }
        TotalLbl.setText(String.format("Total: $%.2f", total));
        //TODO fix this to be correct
        RemainingLbl.setText(String.format("Remaining: $%.2f", total - selectedOrder.getAmountPaid()));
    }

    private void loadOrderIntoCart() {
        cartModel.setRowCount(0);
        originalItemsCount = selectedOrder.getMedicines().size();

        for (int i = 0; i < selectedOrder.getMedicines().size(); i++) {
            Medicine med = selectedOrder.getMedicines().get(i);
            int qty = selectedOrder.getQuantities().get(i);
            cartModel.addRow(new Object[]{
                med.getName(),
                qty,
                med.getPrice() * qty,
                "🔒"
            });
        }
    }

    private void updatePaymentDisplay() {
        PaidAmountLbl.setText("Paid: $" + selectedOrder.getAmountPaid());
        updateTotal();
    }

    private void enableOrderControls() {
        CancelOrderBtn.setEnabled(true);
        Purchase.setEnabled(true);
    }

    private void disableOrderControls() {
        CancelOrderBtn.setEnabled(false);
        Purchase.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CheckOutPanel = new GUI.components.PanelBorder();
        Cart = new javax.swing.JScrollPane();
        tblCart = new javax.swing.JTable();
        ORDERCART = new javax.swing.JLabel();
        TotalLbl = new javax.swing.JLabel();
        Purchase = new javax.swing.JButton();
        Payment = new javax.swing.JPanel();
        PaymentLbl = new javax.swing.JLabel();
        PaymentField = new javax.swing.JTextField();
        PaymentSeperator = new javax.swing.JSeparator();
        PaidAmountLbl = new javax.swing.JLabel();
        CancelOrderBtn = new javax.swing.JButton();
        RemainingLbl = new javax.swing.JLabel();
        MedicineList = new javax.swing.JScrollPane();
        MedicineListPanel = new GUI.components.PanelBorder();
        BackBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        OrderListPanel = new GUI.components.PanelBorder();
        Logout = new javax.swing.JLabel();
        Close = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        CheckOutPanel.setBackground(new java.awt.Color(248, 248, 255));

        tblCart.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Cart.setViewportView(tblCart);

        ORDERCART.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        ORDERCART.setForeground(java.awt.Color.black);
        ORDERCART.setText("ORDER CART");

        TotalLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        TotalLbl.setForeground(new java.awt.Color(64, 77, 161));
        TotalLbl.setText("Total: $0.00");

        Purchase.setBackground(new java.awt.Color(64, 77, 161));
        Purchase.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        Purchase.setForeground(java.awt.Color.white);
        Purchase.setText("Purchase");
        Purchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PurchaseActionPerformed(evt);
            }
        });

        Payment.setBackground(new java.awt.Color(255, 255, 255));
        Payment.setFocusable(false);
        Payment.setOpaque(false);

        PaymentLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        PaymentLbl.setForeground(new java.awt.Color(64, 77, 161));
        PaymentLbl.setText("Enter Additional Amount");

        PaymentField.setBackground(new java.awt.Color(248, 248, 255));
        PaymentField.setBorder(null);

        javax.swing.GroupLayout PaymentLayout = new javax.swing.GroupLayout(Payment);
        Payment.setLayout(PaymentLayout);
        PaymentLayout.setHorizontalGroup(
            PaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PaymentLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(PaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PaymentLbl)
                    .addComponent(PaymentField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PaymentSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        PaymentLayout.setVerticalGroup(
            PaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PaymentLayout.createSequentialGroup()
                .addGap(0, 18, Short.MAX_VALUE)
                .addComponent(PaymentLbl)
                .addGap(4, 4, 4)
                .addComponent(PaymentField, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(PaymentSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 19, Short.MAX_VALUE))
        );

        PaidAmountLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        PaidAmountLbl.setForeground(new java.awt.Color(64, 77, 161));
        PaidAmountLbl.setText("Paid: $0.00");

        CancelOrderBtn.setBackground(new java.awt.Color(255, 0, 51));
        CancelOrderBtn.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        CancelOrderBtn.setText("Cancel");
        CancelOrderBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelOrderBtnActionPerformed(evt);
            }
        });

        RemainingLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        RemainingLbl.setForeground(new java.awt.Color(64, 77, 161));
        RemainingLbl.setText("Remaining From Prev: $0.00");

        javax.swing.GroupLayout CheckOutPanelLayout = new javax.swing.GroupLayout(CheckOutPanel);
        CheckOutPanel.setLayout(CheckOutPanelLayout);
        CheckOutPanelLayout.setHorizontalGroup(
            CheckOutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CheckOutPanelLayout.createSequentialGroup()
                .addGroup(CheckOutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CheckOutPanelLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(Cart, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(CheckOutPanelLayout.createSequentialGroup()
                        .addGap(148, 148, 148)
                        .addComponent(ORDERCART))
                    .addGroup(CheckOutPanelLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(CheckOutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(CheckOutPanelLayout.createSequentialGroup()
                                .addComponent(TotalLbl)
                                .addGap(32, 32, 32)
                                .addComponent(PaidAmountLbl)
                                .addGap(18, 18, 18)
                                .addComponent(RemainingLbl))
                            .addComponent(Payment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(CheckOutPanelLayout.createSequentialGroup()
                                .addComponent(CancelOrderBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(36, 36, 36)
                                .addComponent(Purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        CheckOutPanelLayout.setVerticalGroup(
            CheckOutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CheckOutPanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(ORDERCART)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Cart, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addGroup(CheckOutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TotalLbl)
                    .addComponent(PaidAmountLbl)
                    .addComponent(RemainingLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Payment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CheckOutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Purchase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(CancelOrderBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        MedicineList.setBorder(null);
        MedicineList.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        MedicineList.setOpaque(true);

        MedicineListPanel.setLayout(new javax.swing.BoxLayout(MedicineListPanel, javax.swing.BoxLayout.Y_AXIS));
        MedicineList.setViewportView(MedicineListPanel);

        BackBtn.setBackground(new java.awt.Color(64, 77, 161));
        BackBtn.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        BackBtn.setForeground(java.awt.Color.white);
        BackBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/arrow.png"))); // NOI18N
        BackBtn.setText("Back to Menu");
        BackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtnActionPerformed(evt);
            }
        });

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        OrderListPanel.setBackground(java.awt.Color.white);
        OrderListPanel.setLayout(new javax.swing.BoxLayout(OrderListPanel, javax.swing.BoxLayout.LINE_AXIS));
        jScrollPane1.setViewportView(OrderListPanel);

        Logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logout.png"))); // NOI18N
        Logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutMouseClicked(evt);
            }
        });

        Close.setBackground(java.awt.Color.white);
        Close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Close.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Close.jpg"))); // NOI18N
        Close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CloseMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Logout, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(Close, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1235, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(MedicineList, javax.swing.GroupLayout.PREFERRED_SIZE, 745, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(CheckOutPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(17, 17, 17)
                    .addComponent(BackBtn)
                    .addContainerGap(1128, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Logout, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Close, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CheckOutPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(MedicineList, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(80, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(14, 14, 14)
                    .addComponent(BackBtn)
                    .addContainerGap(679, Short.MAX_VALUE)))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void PurchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PurchaseActionPerformed
        ArrayList<Medicine> selectedMedicines = new ArrayList<>();
        ArrayList<Integer> quantities = new ArrayList<>();
        String medName;
        String Total = TotalLbl.getText();
        Medicine med;
        String paymentAmountStr = PaymentField.getText();
        double paymentAmount;

        try {
            paymentAmount = Double.parseDouble(paymentAmountStr);

            if (paymentAmount <= 0) {
                JOptionPane.showMessageDialog(null, "Payment must be positive", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }

        for (int i = 0; i < cartModel.getRowCount(); i++) {
            if (cartModel.getValueAt(i, 3).equals("❌")) {
                medName = (String) cartModel.getValueAt(i, 0);
                med = findMedicineByIdOrName(medName);
                if (med != null);
                selectedMedicines.add(med);
                quantities.add((Integer) cartModel.getValueAt(i, 1));
            }
        }

        if (new UpdateOrder().oper(u, selectedOrder.getOrderId(), selectedMedicines, quantities, paymentAmount)) {
            new ClientMainMenu(u).setVisible(true);
            this.dispose();
        }

    }//GEN-LAST:event_PurchaseActionPerformed


    private void BackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtnActionPerformed
        new ClientMainMenu(u).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackBtnActionPerformed

    private void CancelOrderBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelOrderBtnActionPerformed
        new CancelOrder().oper(u, selectedOrder.getOrderId());
    }//GEN-LAST:event_CancelOrderBtnActionPerformed

    private void LogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseClicked
        new LoginMenu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_LogoutMouseClicked

    private void CloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseMouseClicked
        this.dispose();
    }//GEN-LAST:event_CloseMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateOrderGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateOrderGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateOrderGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateOrderGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new UpdateOrderGUI(u).setVisible(true);
                } catch (MalformedURLException ex) {
                    Logger.getLogger(UpdateOrderGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackBtn;
    private javax.swing.JButton CancelOrderBtn;
    private javax.swing.JScrollPane Cart;
    private GUI.components.PanelBorder CheckOutPanel;
    private javax.swing.JLabel Close;
    private javax.swing.JLabel Logout;
    private javax.swing.JScrollPane MedicineList;
    private GUI.components.PanelBorder MedicineListPanel;
    private javax.swing.JLabel ORDERCART;
    private GUI.components.PanelBorder OrderListPanel;
    private javax.swing.JLabel PaidAmountLbl;
    private javax.swing.JPanel Payment;
    private javax.swing.JTextField PaymentField;
    private javax.swing.JLabel PaymentLbl;
    private javax.swing.JSeparator PaymentSeperator;
    private javax.swing.JButton Purchase;
    private javax.swing.JLabel RemainingLbl;
    private javax.swing.JLabel TotalLbl;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblCart;
    // End of variables declaration//GEN-END:variables
}
