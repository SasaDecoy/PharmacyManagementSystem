package GUI.ClientGUI;

import GUI.ClientMainMenu;
import GUI.LoginMenu;
import GUI.components.MedicineCard;
import clientOptions.OrderMedicine;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import mainClasses.*;
import static utils.CommonFunctions.*;

public class OrderMedicineGUI extends javax.swing.JFrame {

    private static Client u;
    DefaultTableModel cartModel;
    ArrayList<Medicine> allMedicine = loadMedicines();

    public OrderMedicineGUI(Client u) throws MalformedURLException {
        this.u = u;
        initComponents();

        cartModel = new DefaultTableModel(
                new Object[]{"Medicine", "Quantity", "Price", ""}, 0
        );
        tblCart.setModel(cartModel);

        for (Medicine med : allMedicine) {
            MedicineCard card = new MedicineCard(med, cartModel, TotalLbl, u);
            MedicineListPanel.add(card);
        }

        tblCart.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int column = tblCart.columnAtPoint(e.getPoint());
                int row = tblCart.rowAtPoint(e.getPoint());

                if (column == 3 && row >= 0) {
                    cartModel.removeRow(row);
                    updateTotal();
                }
            }
        });
        for (Medicine med : allMedicine) {
            System.out.println(med.getName());
            MedicineCard card = new MedicineCard(med, cartModel, TotalLbl, u);
            MedicineListPanel.add(card);
        }
    }

    private void updateTotal() {
        double total = 0;
        for (int i = 0; i < cartModel.getRowCount(); i++) {
            total += (double) cartModel.getValueAt(i, 2);
        }
        TotalLbl.setText(String.format("Total: $%.2f", total));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ContentPanel = new javax.swing.JPanel();
        CheckOutPanel = new GUI.components.PanelBorder();
        Cart = new javax.swing.JScrollPane();
        tblCart = new javax.swing.JTable();
        ORDERCART = new javax.swing.JLabel();
        TotalLbl = new javax.swing.JLabel();
        Purchase = new javax.swing.JButton();
        Payment = new javax.swing.JPanel();
        PaymentLbl = new javax.swing.JLabel();
        PaymentField = new javax.swing.JTextField();
        PaymentSeperator = new javax.swing.JSeparator();
        SearchPanel = new javax.swing.JPanel();
        SearchIcon = new javax.swing.JLabel();
        SearchField = new javax.swing.JTextField();
        SearchSeperator = new javax.swing.JSeparator();
        SearchBtn = new javax.swing.JButton();
        MedicieListContainer = new GUI.components.PanelBorder();
        MedicineList = new javax.swing.JScrollPane();
        MedicineListPanel = new javax.swing.JPanel();
        BackBtn = new javax.swing.JButton();
        Logout = new javax.swing.JLabel();
        Close = new javax.swing.JLabel();
        BG = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(244, 244, 244));
        setUndecorated(true);

        ContentPanel.setOpaque(false);

        CheckOutPanel.setBackground(new java.awt.Color(248, 248, 255));

        tblCart.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Cart.setViewportView(tblCart);

        ORDERCART.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        ORDERCART.setForeground(java.awt.Color.black);
        ORDERCART.setText("ORDER CART");

        TotalLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        TotalLbl.setForeground(new java.awt.Color(64, 77, 161));
        TotalLbl.setText("Total: $0.00");

        Purchase.setBackground(new java.awt.Color(64, 77, 161));
        Purchase.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        Purchase.setForeground(java.awt.Color.white);
        Purchase.setText("Purchase");
        Purchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PurchaseActionPerformed(evt);
            }
        });

        Payment.setBackground(new java.awt.Color(255, 255, 255));
        Payment.setFocusable(false);
        Payment.setOpaque(false);

        PaymentLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        PaymentLbl.setForeground(new java.awt.Color(64, 77, 161));
        PaymentLbl.setText("Enter Payment Amount");

        PaymentField.setBackground(new java.awt.Color(248, 248, 255));
        PaymentField.setBorder(null);

        javax.swing.GroupLayout PaymentLayout = new javax.swing.GroupLayout(Payment);
        Payment.setLayout(PaymentLayout);
        PaymentLayout.setHorizontalGroup(
            PaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(PaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PaymentLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(PaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(PaymentLbl)
                        .addComponent(PaymentField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(PaymentSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        PaymentLayout.setVerticalGroup(
            PaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
            .addGroup(PaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PaymentLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(PaymentLbl)
                    .addGap(4, 4, 4)
                    .addComponent(PaymentField, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(2, 2, 2)
                    .addComponent(PaymentSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout CheckOutPanelLayout = new javax.swing.GroupLayout(CheckOutPanel);
        CheckOutPanel.setLayout(CheckOutPanelLayout);
        CheckOutPanelLayout.setHorizontalGroup(
            CheckOutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CheckOutPanelLayout.createSequentialGroup()
                .addGroup(CheckOutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CheckOutPanelLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(Cart, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(CheckOutPanelLayout.createSequentialGroup()
                        .addGap(148, 148, 148)
                        .addComponent(ORDERCART))
                    .addGroup(CheckOutPanelLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(CheckOutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TotalLbl)
                            .addComponent(Payment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        CheckOutPanelLayout.setVerticalGroup(
            CheckOutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CheckOutPanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(ORDERCART)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Cart, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addComponent(TotalLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Payment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Purchase)
                .addGap(56, 56, 56))
        );

        SearchPanel.setOpaque(false);

        SearchIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N

        SearchField.setBorder(null);

        SearchBtn.setBackground(new java.awt.Color(64, 77, 161));
        SearchBtn.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        SearchBtn.setForeground(java.awt.Color.white);
        SearchBtn.setText("Search");
        SearchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SearchPanelLayout = new javax.swing.GroupLayout(SearchPanel);
        SearchPanel.setLayout(SearchPanelLayout);
        SearchPanelLayout.setHorizontalGroup(
            SearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SearchPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SearchIcon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(SearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(SearchSeperator)
                    .addComponent(SearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchBtn)
                .addContainerGap(65, Short.MAX_VALUE))
        );
        SearchPanelLayout.setVerticalGroup(
            SearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SearchPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(SearchIcon, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
                        .addComponent(SearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(SearchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        MedicieListContainer.setBackground(new java.awt.Color(64, 77, 161));

        MedicineList.setBorder(null);
        MedicineList.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        MedicineListPanel.setBackground(new java.awt.Color(64, 77, 161));
        MedicineListPanel.setLayout(new javax.swing.BoxLayout(MedicineListPanel, javax.swing.BoxLayout.PAGE_AXIS));
        MedicineList.setViewportView(MedicineListPanel);

        javax.swing.GroupLayout MedicieListContainerLayout = new javax.swing.GroupLayout(MedicieListContainer);
        MedicieListContainer.setLayout(MedicieListContainerLayout);
        MedicieListContainerLayout.setHorizontalGroup(
            MedicieListContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MedicieListContainerLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MedicineList, javax.swing.GroupLayout.PREFERRED_SIZE, 746, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        MedicieListContainerLayout.setVerticalGroup(
            MedicieListContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MedicieListContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MedicineList, javax.swing.GroupLayout.DEFAULT_SIZE, 578, Short.MAX_VALUE)
                .addContainerGap())
        );

        BackBtn.setBackground(new java.awt.Color(64, 77, 161));
        BackBtn.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        BackBtn.setForeground(java.awt.Color.white);
        BackBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/arrow.png"))); // NOI18N
        BackBtn.setText("Back to Menu");
        BackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtnActionPerformed(evt);
            }
        });

        Logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logout.png"))); // NOI18N
        Logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutMouseClicked(evt);
            }
        });

        Close.setBackground(java.awt.Color.white);
        Close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Close.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Close.jpg"))); // NOI18N
        Close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CloseMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout ContentPanelLayout = new javax.swing.GroupLayout(ContentPanel);
        ContentPanel.setLayout(ContentPanelLayout);
        ContentPanelLayout.setHorizontalGroup(
            ContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContentPanelLayout.createSequentialGroup()
                .addGroup(ContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ContentPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(BackBtn)
                        .addGap(29, 29, 29)
                        .addComponent(SearchPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ContentPanelLayout.createSequentialGroup()
                        .addContainerGap(67, Short.MAX_VALUE)
                        .addComponent(MedicieListContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(ContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CheckOutPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ContentPanelLayout.createSequentialGroup()
                        .addComponent(Logout, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(Close, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)))
                .addContainerGap())
        );
        ContentPanelLayout.setVerticalGroup(
            ContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContentPanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(ContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(ContentPanelLayout.createSequentialGroup()
                        .addGroup(ContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BackBtn)
                            .addComponent(SearchPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(MedicieListContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(ContentPanelLayout.createSequentialGroup()
                        .addGroup(ContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Logout, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Close, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(85, 85, 85)
                        .addComponent(CheckOutPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        BG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ClientOptionsBg.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ContentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(BG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ContentPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(BG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtnActionPerformed
        new ClientMainMenu(u).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackBtnActionPerformed

    private void SearchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchBtnActionPerformed
        String search = SearchField.getText();
        MedicineListPanel.removeAll();
        ArrayList<Medicine> allMedicine = searchMedicines(search);
        if (allMedicine.isEmpty()) {
            MedicineListPanel.removeAll();
        } else {
            for (Medicine med : allMedicine) {
                MedicineCard card;
                try {
                    card = new MedicineCard(med, cartModel, TotalLbl, u);
                    MedicineListPanel.add(card);
                } catch (MalformedURLException ex) {

                }
            }
        }
    }//GEN-LAST:event_SearchBtnActionPerformed

    private void PurchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PurchaseActionPerformed
        String paymentAmountStr = PaymentField.getText();
        double paymentAmount;
         try {
            paymentAmount = Double.parseDouble(paymentAmountStr);

            if (paymentAmount <= 0) {
                JOptionPane.showMessageDialog(null, "Payment must be positive", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
         
        ArrayList<Medicine> selectedMedicine = new ArrayList<>();
        ArrayList<Integer> quantities = new ArrayList<>();
        String medName;
        String Total = TotalLbl.getText();
        Medicine med;
        for (int i = 0; i < cartModel.getRowCount(); i++) {
            medName = (String) cartModel.getValueAt(i, 0);
            med = findMedicineByIdOrName(medName);
            if (med != null);
            selectedMedicine.add(med);
            quantities.add((Integer) cartModel.getValueAt(i, 1));
        }

        if (new OrderMedicine().oper(u, paymentAmount, selectedMedicine, quantities, Total)) {
            new ClientMainMenu(u).setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_PurchaseActionPerformed

    private void LogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseClicked
        new LoginMenu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_LogoutMouseClicked

    private void CloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseMouseClicked
        this.dispose();
    }//GEN-LAST:event_CloseMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OrderMedicineGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OrderMedicineGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OrderMedicineGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OrderMedicineGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new OrderMedicineGUI(u).setVisible(true);
                } catch (MalformedURLException ex) {
                    Logger.getLogger(OrderMedicineGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BG;
    private javax.swing.JButton BackBtn;
    private javax.swing.JScrollPane Cart;
    private GUI.components.PanelBorder CheckOutPanel;
    private javax.swing.JLabel Close;
    private javax.swing.JPanel ContentPanel;
    private javax.swing.JLabel Logout;
    private GUI.components.PanelBorder MedicieListContainer;
    private javax.swing.JScrollPane MedicineList;
    private javax.swing.JPanel MedicineListPanel;
    private javax.swing.JLabel ORDERCART;
    private javax.swing.JPanel Payment;
    private javax.swing.JTextField PaymentField;
    private javax.swing.JLabel PaymentLbl;
    private javax.swing.JSeparator PaymentSeperator;
    private javax.swing.JButton Purchase;
    private javax.swing.JButton SearchBtn;
    private javax.swing.JTextField SearchField;
    private javax.swing.JLabel SearchIcon;
    private javax.swing.JPanel SearchPanel;
    private javax.swing.JSeparator SearchSeperator;
    private javax.swing.JLabel TotalLbl;
    private javax.swing.JTable tblCart;
    // End of variables declaration//GEN-END:variables
}
