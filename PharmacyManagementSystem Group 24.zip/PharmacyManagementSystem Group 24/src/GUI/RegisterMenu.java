package GUI;

import javax.swing.ImageIcon;
import pharmacymanagementsystemconsole.PharmacyManagementSystemGUI;
import publicOptions.CreateAccount;

public class RegisterMenu extends javax.swing.JFrame {

    char defaultEchoChar;

    public RegisterMenu() {
        initComponents();
        defaultEchoChar = ConfirmPasswordField.getEchoChar();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        RegisterPanel = new javax.swing.JPanel();
        Content = new javax.swing.JPanel();
        Name = new javax.swing.JPanel();
        NameLbl = new javax.swing.JLabel();
        NameField = new javax.swing.JTextField();
        NameSeperator = new javax.swing.JSeparator();
        Username = new javax.swing.JPanel();
        UsernameLbl = new javax.swing.JLabel();
        UsernameField = new javax.swing.JTextField();
        UsernameSeperator = new javax.swing.JSeparator();
        Password = new javax.swing.JPanel();
        PasswordLbl = new javax.swing.JLabel();
        RevealPassword = new javax.swing.JButton();
        PasswordField = new javax.swing.JPasswordField();
        PasswordSeperator = new javax.swing.JSeparator();
        ConfirmPassword = new javax.swing.JPanel();
        ConfirmPasswordLbl = new javax.swing.JLabel();
        RevealConfirmPassword = new javax.swing.JButton();
        ConfirmPasswordField = new javax.swing.JPasswordField();
        ConfirmPasswordSeperator = new javax.swing.JSeparator();
        Phone = new javax.swing.JPanel();
        PhoneLbl = new javax.swing.JLabel();
        PhoneField = new javax.swing.JTextField();
        PhoneSeperator = new javax.swing.JSeparator();
        DOB = new javax.swing.JPanel();
        DOBLbl = new javax.swing.JLabel();
        DOBField = new javax.swing.JTextField();
        DOBSeperator = new javax.swing.JSeparator();
        LoginBtn = new javax.swing.JButton();
        Login = new javax.swing.JPanel();
        LoginMsg = new javax.swing.JLabel();
        SignUp = new javax.swing.JLabel();
        RegisterLogo = new javax.swing.JLabel();
        Close = new javax.swing.JLabel();
        LoginImg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        RegisterPanel.setBackground(new java.awt.Color(176, 235, 255));
        RegisterPanel.setPreferredSize(new java.awt.Dimension(640, 720));
        RegisterPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Content.setBackground(new java.awt.Color(248, 248, 255));
        Content.setOpaque(false);
        Content.setPreferredSize(new java.awt.Dimension(640, 720));
        Content.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Name.setBackground(new java.awt.Color(255, 255, 255));
        Name.setFocusable(false);
        Name.setOpaque(false);

        NameLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        NameLbl.setForeground(new java.awt.Color(64, 77, 161));
        NameLbl.setText("Name");

        NameField.setBackground(new java.awt.Color(232, 240, 249));
        NameField.setBorder(null);

        javax.swing.GroupLayout NameLayout = new javax.swing.GroupLayout(Name);
        Name.setLayout(NameLayout);
        NameLayout.setHorizontalGroup(
            NameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(NameLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(NameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(NameLbl)
                    .addComponent(NameField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NameSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        NameLayout.setVerticalGroup(
            NameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(NameLayout.createSequentialGroup()
                .addGap(0, 7, Short.MAX_VALUE)
                .addComponent(NameLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(NameField, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NameSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        Content.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 140, -1, 60));

        Username.setBackground(new java.awt.Color(255, 255, 255));
        Username.setFocusable(false);
        Username.setOpaque(false);

        UsernameLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        UsernameLbl.setForeground(new java.awt.Color(64, 77, 161));
        UsernameLbl.setText("Username");

        UsernameField.setBackground(new java.awt.Color(232, 240, 249));
        UsernameField.setBorder(null);

        javax.swing.GroupLayout UsernameLayout = new javax.swing.GroupLayout(Username);
        Username.setLayout(UsernameLayout);
        UsernameLayout.setHorizontalGroup(
            UsernameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UsernameLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(UsernameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(UsernameLbl)
                    .addComponent(UsernameField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UsernameSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        UsernameLayout.setVerticalGroup(
            UsernameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UsernameLayout.createSequentialGroup()
                .addGap(0, 7, Short.MAX_VALUE)
                .addComponent(UsernameLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(UsernameField, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(UsernameSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        Content.add(Username, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, -1, 60));

        Password.setOpaque(false);

        PasswordLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        PasswordLbl.setForeground(new java.awt.Color(64, 77, 161));
        PasswordLbl.setText("Password");

        RevealPassword.setBackground(java.awt.Color.white);
        RevealPassword.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/eyeClosed.png"))); // NOI18N
        RevealPassword.setBorder(null);
        RevealPassword.setContentAreaFilled(false);
        RevealPassword.setFocusPainted(false);
        RevealPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RevealPasswordActionPerformed(evt);
            }
        });

        PasswordField.setBackground(new java.awt.Color(232, 240, 249));
        PasswordField.setBorder(null);

        javax.swing.GroupLayout PasswordLayout = new javax.swing.GroupLayout(Password);
        Password.setLayout(PasswordLayout);
        PasswordLayout.setHorizontalGroup(
            PasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PasswordLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RevealPassword)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PasswordLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(PasswordSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(PasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PasswordLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(PasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(PasswordLbl)
                        .addComponent(PasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 9, Short.MAX_VALUE)))
        );
        PasswordLayout.setVerticalGroup(
            PasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PasswordLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(RevealPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PasswordSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
            .addGroup(PasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PasswordLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(PasswordLbl)
                    .addGap(4, 4, 4)
                    .addComponent(PasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 10, Short.MAX_VALUE)))
        );

        Content.add(Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 280, -1, 70));

        ConfirmPassword.setOpaque(false);

        ConfirmPasswordLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        ConfirmPasswordLbl.setForeground(new java.awt.Color(64, 77, 161));
        ConfirmPasswordLbl.setText("ConfirmPassword");

        RevealConfirmPassword.setBackground(java.awt.Color.white);
        RevealConfirmPassword.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/eyeClosed.png"))); // NOI18N
        RevealConfirmPassword.setBorder(null);
        RevealConfirmPassword.setContentAreaFilled(false);
        RevealConfirmPassword.setFocusPainted(false);
        RevealConfirmPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RevealConfirmPasswordActionPerformed(evt);
            }
        });

        ConfirmPasswordField.setBackground(new java.awt.Color(232, 240, 249));
        ConfirmPasswordField.setBorder(null);

        javax.swing.GroupLayout ConfirmPasswordLayout = new javax.swing.GroupLayout(ConfirmPassword);
        ConfirmPassword.setLayout(ConfirmPasswordLayout);
        ConfirmPasswordLayout.setHorizontalGroup(
            ConfirmPasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ConfirmPasswordLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RevealConfirmPassword)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ConfirmPasswordLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ConfirmPasswordSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(ConfirmPasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(ConfirmPasswordLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(ConfirmPasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(ConfirmPasswordLbl)
                        .addComponent(ConfirmPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 9, Short.MAX_VALUE)))
        );
        ConfirmPasswordLayout.setVerticalGroup(
            ConfirmPasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ConfirmPasswordLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(RevealConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ConfirmPasswordSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
            .addGroup(ConfirmPasswordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(ConfirmPasswordLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ConfirmPasswordLbl)
                    .addGap(4, 4, 4)
                    .addComponent(ConfirmPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 10, Short.MAX_VALUE)))
        );

        Content.add(ConfirmPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 350, -1, 70));

        Phone.setBackground(new java.awt.Color(255, 255, 255));
        Phone.setFocusable(false);
        Phone.setOpaque(false);

        PhoneLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        PhoneLbl.setForeground(new java.awt.Color(64, 77, 161));
        PhoneLbl.setText("Phone");

        PhoneField.setBackground(new java.awt.Color(232, 240, 249));
        PhoneField.setBorder(null);

        javax.swing.GroupLayout PhoneLayout = new javax.swing.GroupLayout(Phone);
        Phone.setLayout(PhoneLayout);
        PhoneLayout.setHorizontalGroup(
            PhoneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PhoneLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(PhoneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PhoneLbl)
                    .addComponent(PhoneField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PhoneSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        PhoneLayout.setVerticalGroup(
            PhoneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PhoneLayout.createSequentialGroup()
                .addGap(0, 7, Short.MAX_VALUE)
                .addComponent(PhoneLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(PhoneField, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PhoneSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        Content.add(Phone, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 420, -1, 60));

        DOB.setBackground(new java.awt.Color(255, 255, 255));
        DOB.setFocusable(false);
        DOB.setOpaque(false);

        DOBLbl.setFont(new java.awt.Font("Berlin Sans FB", 0, 14)); // NOI18N
        DOBLbl.setForeground(new java.awt.Color(64, 77, 161));
        DOBLbl.setText("Date of birth (DD/MM/YYYY)");

        DOBField.setBackground(new java.awt.Color(232, 240, 249));
        DOBField.setBorder(null);

        javax.swing.GroupLayout DOBLayout = new javax.swing.GroupLayout(DOB);
        DOB.setLayout(DOBLayout);
        DOBLayout.setHorizontalGroup(
            DOBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DOBLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(DOBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DOBLbl)
                    .addComponent(DOBField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DOBSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        DOBLayout.setVerticalGroup(
            DOBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DOBLayout.createSequentialGroup()
                .addGap(0, 7, Short.MAX_VALUE)
                .addComponent(DOBLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(DOBField, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DOBSeperator, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        Content.add(DOB, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 490, -1, 60));

        LoginBtn.setBackground(new java.awt.Color(64, 77, 161));
        LoginBtn.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        LoginBtn.setForeground(java.awt.Color.white);
        LoginBtn.setText("Sign up");
        LoginBtn.setBorder(null);
        LoginBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginBtnActionPerformed(evt);
            }
        });
        Content.add(LoginBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 560, 300, 40));

        Login.setOpaque(false);

        LoginMsg.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        LoginMsg.setForeground(java.awt.Color.gray);
        LoginMsg.setText("Already have an Account?");

        SignUp.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        SignUp.setForeground(new java.awt.Color(51, 51, 255));
        SignUp.setText("Sign in");
        SignUp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SignUpMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SignUpMouseEntered(evt);
            }
        });

        javax.swing.GroupLayout LoginLayout = new javax.swing.GroupLayout(Login);
        Login.setLayout(LoginLayout);
        LoginLayout.setHorizontalGroup(
            LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LoginMsg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SignUp)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        LoginLayout.setVerticalGroup(
            LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LoginLayout.createSequentialGroup()
                .addContainerGap(10, Short.MAX_VALUE)
                .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LoginMsg)
                    .addComponent(SignUp))
                .addContainerGap())
        );

        Content.add(Login, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 600, 210, 30));

        RegisterLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/RegisterLogo.png"))); // NOI18N
        Content.add(RegisterLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, -1, -1));

        Close.setBackground(java.awt.Color.white);
        Close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Close.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Close.jpg"))); // NOI18N
        Close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CloseMouseClicked(evt);
            }
        });
        Content.add(Close, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 10, -1, -1));

        RegisterPanel.add(Content, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 0, 652, -1));

        LoginImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/newBg.jpg"))); // NOI18N
        RegisterPanel.add(LoginImg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(RegisterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(RegisterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void RevealPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RevealPasswordActionPerformed
        if (PasswordField.getEchoChar() == defaultEchoChar) {
            PasswordField.setEchoChar((char) 0);
            RevealPassword.setIcon(new ImageIcon(getClass().getResource("/images/openEyes.png")));
        } else {
            PasswordField.setEchoChar(defaultEchoChar);
            RevealPassword.setIcon(new ImageIcon(getClass().getResource("/images/eyeClosed.png")));
        }
    }//GEN-LAST:event_RevealPasswordActionPerformed

    private void LoginBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginBtnActionPerformed

        String name = NameField.getText();
        String username = UsernameField.getText();
        String password = new String(PasswordField.getPassword());
        String confirmPassword = new String(ConfirmPasswordField.getPassword());
        String phoneNumber = PhoneField.getText();
        String dateOfBirth = DOBField.getText();
        if (CreateAccount.registerUser(name, username, password, confirmPassword, phoneNumber, dateOfBirth)) {
            new LoginMenu().setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_LoginBtnActionPerformed

    private void SignUpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SignUpMouseClicked
        new LoginMenu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_SignUpMouseClicked

    private void SignUpMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SignUpMouseEntered
        SignUp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
    }//GEN-LAST:event_SignUpMouseEntered

    private void RevealConfirmPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RevealConfirmPasswordActionPerformed
        if (ConfirmPasswordField.getEchoChar() == defaultEchoChar) {
            ConfirmPasswordField.setEchoChar((char) 0);
            RevealConfirmPassword.setIcon(new ImageIcon(getClass().getResource("/images/openEyes.png")));
        } else {
            ConfirmPasswordField.setEchoChar(defaultEchoChar);
            RevealConfirmPassword.setIcon(new ImageIcon(getClass().getResource("/images/eyeClosed.png")));
        }
    }//GEN-LAST:event_RevealConfirmPasswordActionPerformed

    private void CloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseMouseClicked
        this.dispose();
    }//GEN-LAST:event_CloseMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegisterMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegisterMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegisterMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegisterMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegisterMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Close;
    private javax.swing.JPanel ConfirmPassword;
    private javax.swing.JPasswordField ConfirmPasswordField;
    private javax.swing.JLabel ConfirmPasswordLbl;
    private javax.swing.JSeparator ConfirmPasswordSeperator;
    private javax.swing.JPanel Content;
    private javax.swing.JPanel DOB;
    private javax.swing.JTextField DOBField;
    private javax.swing.JLabel DOBLbl;
    private javax.swing.JSeparator DOBSeperator;
    private javax.swing.JPanel Login;
    private javax.swing.JButton LoginBtn;
    private javax.swing.JLabel LoginImg;
    private javax.swing.JLabel LoginMsg;
    private javax.swing.JPanel Name;
    private javax.swing.JTextField NameField;
    private javax.swing.JLabel NameLbl;
    private javax.swing.JSeparator NameSeperator;
    private javax.swing.JPanel Password;
    private javax.swing.JPasswordField PasswordField;
    private javax.swing.JLabel PasswordLbl;
    private javax.swing.JSeparator PasswordSeperator;
    private javax.swing.JPanel Phone;
    private javax.swing.JTextField PhoneField;
    private javax.swing.JLabel PhoneLbl;
    private javax.swing.JSeparator PhoneSeperator;
    private javax.swing.JLabel RegisterLogo;
    private javax.swing.JPanel RegisterPanel;
    private javax.swing.JButton RevealConfirmPassword;
    private javax.swing.JButton RevealPassword;
    private javax.swing.JLabel SignUp;
    private javax.swing.JPanel Username;
    private javax.swing.JTextField UsernameField;
    private javax.swing.JLabel UsernameLbl;
    private javax.swing.JSeparator UsernameSeperator;
    // End of variables declaration//GEN-END:variables
}
