package publicOptions;

import mainClasses.User;
import mainClasses.Option;
import java.util.Scanner;
import static utils.CommonFunctions.*;

public class SearchMedicine implements Option{

    @Override
    public String getOption() {
       return "🔍 Search For Medicine";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- Search Medicine ---");
        String search = getStringInput(s, "Search by anything (id, name, stock, company, price) (0 to exit): ");
        
        if(search.equals("0")){
            System.out.println("\n==Returning to menu==");
            return;
        }
        
        searchMedicines(search);
    }
    
}
