package publicOptions;

import mainClasses.User;
import mainClasses.Option;
import java.util.*;
import static utils.CommonFunctions.searchMedicines;

public class ViewAllMedicines implements Option {

    @Override
    public String getOption() {
        return "💊 View All Medicines";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- View All Medicines ---");
        searchMedicines("");
        
    }
}
