package publicOptions;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import mainClasses.*;
import static utils.CommonFunctions.loadAllUsers;

public class CreateAccount {

    public static boolean registerUser(String name, String username, String password, String confirmPassword, String phone, String dateOfBirth) {
        ArrayList<User> allUsers = loadAllUsers(null);
        ArrayList<String> allUsernames = new ArrayList<>();
        
        if(name.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "❌ Can't leave name empty.");
            return false;
        }
        if(username.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "❌ Can't leave username empty.");
            return false;
        }
        if(password.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "❌ Can't leave password empty.");
            return false;
        }
        if(confirmPassword.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "❌ Can't leave confirmPassword empty.");
            return false;
        }
        if(phone.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "❌ Can't leave phone empty.");
            return false;
        }
        if(dateOfBirth.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "❌ Can't leave dateOfBirth empty.");
            return false;
        }
        
        for (User user : allUsers) {
            allUsernames.add(user.getUsername());
        }

        if (allUsernames.contains(username)) {
            JOptionPane.showMessageDialog(null, "❌ Username already exists!");
            return false;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(null,"❌ Passwords do not match!");
            return false;
        }

      
        new Client(name, username, password, phone, dateOfBirth);
        JOptionPane.showMessageDialog(null,"✅ Client account created successfully!");
        return true;
         
    }
}
