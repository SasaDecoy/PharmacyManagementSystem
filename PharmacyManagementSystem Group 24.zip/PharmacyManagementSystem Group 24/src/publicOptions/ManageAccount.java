package publicOptions;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import mainClasses.*;
import static utils.CommonFunctions.*;

public class ManageAccount implements Option {

    private static final String DOCTORS_FILE = "Data/doctors.csv";
    private static final String ADMINS_FILE = "Data/admins.csv";
    private static final String CLIENTS_FILE = "Data/clients.csv";

    @Override
    public String getOption() {
        return "🔧 Manage Account";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- Manage Account ---");

        String file = u instanceof Doctor ? DOCTORS_FILE: u instanceof Admin ? ADMINS_FILE : CLIENTS_FILE;
        
        ArrayList<String> updatedUsers = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(file))) {
            if (scanner.hasNextLine()) {
                updatedUsers.add(scanner.nextLine());
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",", -1);

                if (parts[0].equals(String.valueOf(u.getId()))) {
                    System.out.println("\nEditing Account: " + u.getUsername());

                    while (true) {
                        System.out.println("\n1. Name");
                        System.out.println("2. Username");
                        System.out.println("3. Password");
                        System.out.println("4. Phone");
                        System.out.println("5. Date of Birth");

                        if (u instanceof Admin || u instanceof Doctor) {
                            System.out.println("6. Start Time");
                            System.out.println("7. End Time");
                            System.out.println("8. Salary");
                        }
                        if (u instanceof Doctor) {
                            System.out.println("9. License Number");
                        }
                        System.out.println("0. Finish Editing");

                        int choice = getIntInput(s, "Enter your choice: ");

                        if (choice == 0) {
                            System.out.println("\n==Returning to menu==");
                            break;
                        }

                        switch (choice) {
                            case 1 -> {
                                String newName = getStringInput(s, "Enter new name (" + parts[1] + "): ");
                                parts[1] = newName.isEmpty() ? parts[1] : newName;
                            }

                            case 2 -> {
                                while (true) {
                                    String newUsername = getStringInput(s, "Enter new username (" + parts[2] + "): ");
                                    if (newUsername.isEmpty()) {
                                        break;
                                    }
                                    if (checkUsername(newUsername)) {
                                        parts[2] = newUsername;
                                        break;
                                    }
                                    System.out.println("❌ Username already exists!");
                                }
                            }

                            case 3 -> {
                                String currentPass = getStringInput(s, "Enter current password: ");
                                if (!currentPass.equals(parts[3])) {
                                    System.out.println("❌ Incorrect password!");
                                    break;
                                }
                                while (true) {
                                    String newPass = getStringInput(s, "Enter new password: ");
                                    String confirmPass = getStringInput(s, "Confirm new password: ");
                                    if (newPass.equals(confirmPass)) {
                                        parts[3] = newPass;
                                        break;
                                    }
                                    System.out.println("❌ Passwords don't match!");
                                }
                            }

                            case 4 -> {
                                String newPhone = getStringInput(s, "Enter new phone (" + parts[4] + "): ");
                                parts[4] = newPhone.isEmpty() ? parts[4] : newPhone;
                            }

                            case 5 -> {
                                String newDateOfBirth = getStringInput(s, "Enter new birth date (d/M/yyyy) (" + parts[5] + "): ");
                                if (!newDateOfBirth.isEmpty()) {
                                    parts[5] = newDateOfBirth;
                                }
                            }

                            case 6 -> {
                                if (u instanceof Admin || u instanceof Doctor) {
                                    String newStartTime = getStringInput(s, "Enter new start time (HH:mm) (" + parts[6] + "): ");
                                    parts[6] = newStartTime.isEmpty() ? parts[6] : newStartTime;
                                }
                            }

                            case 7 -> {
                                if (u instanceof Admin || u instanceof Doctor) {
                                    String newEndTime = getStringInput(s, "Enter new end time (HH:mm) (" + parts[7] + "): ");
                                    parts[7] = newEndTime.isEmpty() ? parts[7] : newEndTime;
                                }
                            }

                            case 8 -> {
                                if (u instanceof Admin || u instanceof Doctor) {
                                    double newSalary = getDoubleInput(s, "Enter new salary (" + parts[8] + "): ");
                                    parts[8] = (newSalary == 0) ? parts[8] : String.valueOf(newSalary);
                                }
                            }

                            case 9 -> {
                                if (u instanceof Doctor) {
                                    while (true) {
                                        int newLicense = getIntInput(s, "Enter new license number (" + parts[9] + "): ");
                                        if (newLicense == 0) {
                                            break;
                                        }
                                        if (checkLicenseNumber(newLicense)) {
                                            parts[9] = String.valueOf(newLicense);
                                            break;
                                        }
                                        System.out.println("❌ License number already exists!");
                                    }
                                }
                            }

                            default ->
                                System.out.println("❌ Invalid choice!");
                        }
                    }
                }
                updatedUsers.add(String.join(",", parts));
            }
        } catch (IOException e) {
            System.out.println("❌ Error reading user data: " + e.getMessage());
            return;
        }

        if (writeInFile(file, updatedUsers)) {
            System.out.println("\n✅ Account updated successfully!");
        } else {
            System.out.println("\n❌ Failed to update account!");
        }
    }

}
