package pharmacymanagementsystemconsole;

import GUI.ClientMainMenu;
import java.util.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import mainClasses.*;
import static utils.CommonFunctions.*;

public class PharmacyManagementSystemGUI {

    public static void processLogin(String username, String password, JFrame LoginFrame) {
        ArrayList<User> allUsers = loadAllUsers(null);
        User loggedInUser = null;

        for (User user : allUsers) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                loggedInUser = user;
            }
        }

        if (loggedInUser != null) {
            loggedInUser.displayInfo();
            if (loggedInUser instanceof Client client) {
                new ClientMainMenu(client).setVisible(true);
                LoginFrame.dispose();
            }
        } else {
            JOptionPane.showMessageDialog(null, "❌ Invalid username or password. Please try again.");
        }
    }

}
