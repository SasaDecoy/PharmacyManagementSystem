package utils;

import java.io.*;
import java.time.LocalDate;
import java.time.format.*;
import java.util.*;
import mainClasses.*;

public class CommonFunctions {

    private static final String CLIENTS_FILE = "Data/clients.csv";
    private static final String DOCTORS_FILE = "Data/doctors.csv";
    private static final String ADMINS_FILE = "Data/admins.csv";
    private static final String MEDICINES_FILE = "Data/medicines.csv";
    private static final String ORDERS_FILE = "Data/orders.csv";
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d/M/yyyy");

    public static ArrayList<Medicine> loadMedicines() {
        ArrayList<Medicine> medicines = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(MEDICINES_FILE))) {
            if (scanner.hasNextLine()) {
                scanner.nextLine();
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                try {
                    int id = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    String composition = parts[2];
                    double price = Double.parseDouble(parts[3]);
                    int stock = Integer.parseInt(parts[4]);
                    String manufacturer = parts[5];
                    LocalDate manufactureDate = LocalDate.parse(parts[6], dateFormatter);
                    LocalDate expirationDate = LocalDate.parse(parts[7], dateFormatter);
                    String uses = parts[9];
                    String sideEffects = parts[10];
                    String ImageUrl = parts[11].isEmpty() ? "" : parts[11].trim().replaceAll("\"", "");

                    ArrayList<String> prescribed = parts[8].equalsIgnoreCase("NULL") ? null : new ArrayList<>();
                    if (!parts[8].equalsIgnoreCase("NULL") && !parts[8].isEmpty()) {
                        prescribed = new ArrayList<>(Arrays.asList(parts[8].split("\\|")));
                    }

                    medicines.add(new Medicine(id, name, composition, price, stock, manufacturer, manufactureDate, expirationDate, prescribed, uses, sideEffects, ImageUrl));
                } catch (NumberFormatException e) {
                    System.out.println("Error➡ " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Error loading medicines: " + e.getMessage());
        }

        return medicines;
    }

    public static ArrayList<Medicine> viewAllMedicineForOrder(User u) {
        ArrayList<Medicine> allMedicines = loadMedicines();
        ArrayList<Medicine> filteredMedicines = new ArrayList<>();
        System.out.println("\n📋 Available Medicines:");

        for (Medicine med : allMedicines) {
            ArrayList<String> prescribedClients = med.getPrescribed();

            if (prescribedClients == null || prescribedClients.contains(String.valueOf(u.getId()))) {
                System.out.println(
                        med.getId() + ". " + med.getName() + " ($" + med.getPrice() + ") - Stock: " + med.getStock());
                filteredMedicines.add(med);
            }
        }
        return filteredMedicines;
    }

    public static ArrayList<Order> loadOrdersByCustomerId(int Id) {
        ArrayList<Medicine> medicines = loadMedicines();
        ArrayList<Order> clientOrders = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(ORDERS_FILE))) {
            if (scanner.hasNextLine()) {
                scanner.nextLine();
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");
                try {
                    int orderId = Integer.parseInt(parts[0]);
                    int currentClientId = Integer.parseInt(parts[1]);

                    if (Id != 0 && currentClientId != Id) {
                        continue;
                    }

                    String medicineData = parts[2];
                    double totalPrice = Double.parseDouble(parts[3]);
                    double amountPaid = Double.parseDouble(parts[4]);
                    double changeAmount = Double.parseDouble(parts[5]);
                    String orderStatus = parts[6];
                    LocalDate orderDate = LocalDate.parse(parts[7], dateFormatter);

                    ArrayList<Medicine> orderMedicines = new ArrayList<>();
                    ArrayList<Integer> quantities = new ArrayList<>();

                    if (!medicineData.equals("NULL")) {
                        for (String medInfo : medicineData.split("\\|")) {
                            String[] medParts = medInfo.split("-");
                            int medId = Integer.parseInt(medParts[0]);
                            int quantity = Integer.parseInt(medParts[1].trim());

                            for (Medicine med : medicines) {
                                if (med.getId() == medId) {
                                    orderMedicines.add(med);
                                    quantities.add(quantity);
                                    break;
                                }
                            }
                        }
                    }

                    clientOrders.add(new Order(orderId, currentClientId, orderMedicines, quantities, totalPrice, amountPaid, changeAmount, orderStatus, orderDate));
                } catch (NumberFormatException e) {
                    System.out.println("Error➡ " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Error loading orders: " + e.getMessage());
        }
        return clientOrders;
    }

    public static Medicine findMedicineByIdOrName(String input) {
        ArrayList<Medicine> allMedicines = loadMedicines();
        for (Medicine med : allMedicines) {
            if (String.valueOf(med.getId()).equals(input) || med.getName().equalsIgnoreCase(input)) {
                return med;
            }
        }
        return null;
    }

    public static Medicine findMedicineById(int medId) {
        ArrayList<Medicine> allMedicines = loadMedicines();
        for (Medicine med : allMedicines) {
            if (med.getId() == medId) {
                return med;
            }
        }
        return null;
    }

    public static void ensureFilesExist() {
        String[][] files = {
            {CLIENTS_FILE, "ID,Name,Username,Password,Phone,DateOfBirth"},
            {DOCTORS_FILE, "ID,Name,Username,Password,Phone,DateOfBirth,StartTime,EndTime,Salary,LicenseNumber"},
            {ADMINS_FILE, "ID,Name,Username,Password,Phone,DateOfBirth,StartTime,EndTime,Salary"},
            {MEDICINES_FILE, "ID,Name,Composition,Price,Stock,Manufacturer,ManufactureDate,ExpirationDate,Perscribed,Uses,SideEffects,ImageUrl"},
            {ORDERS_FILE, "OrderID,CustomerID,Medicines,TotalPrice,AmountPaid,ChangeAmount,OrderStatus"},
            {"Data/last_order_id.csv", "1"},
            {"Data/last_medicine_id.csv", "1"},
            {"Data/last_id.csv", "1"}
        };

        for (String[] fileData : files) {
            File file = new File(fileData[0]);
            if (!file.exists()) {
                try (FileWriter writer = new FileWriter(file)) {
                    writer.write(fileData[1] + "\n");
                    System.out.println("✅ Created missing file: " + fileData[0]);
                } catch (IOException e) {
                    System.out.println("❌ Error creating file: " + fileData[0] + " - " + e.getMessage());
                }
            }
        }
    }

    public static ArrayList<User> loadAllUsers(String userType) {
        ArrayList<User> allUsers = new ArrayList<>();

        if (userType == null || userType.isEmpty() || userType.equals("Client")) {
            try (Scanner scanner = new Scanner(new File(CLIENTS_FILE))) {
                if (!scanner.hasNextLine()) {
                    throw new IOException("❌ No Clients found.");
                }

                if (scanner.hasNextLine()) {
                    scanner.nextLine();
                }

                while (scanner.hasNextLine()) {
                    String[] parts = scanner.nextLine().split(",");
                    try {
                        int id = Integer.parseInt(parts[0]);
                        String name = parts[1];
                        String username = parts[2];
                        String password = parts[3];
                        String phone = parts[4];
                        String dateOfBirth = parts[5];

                        allUsers.add(new Client(id, name, username, password, phone, dateOfBirth));
                    } catch (NumberFormatException e) {
                        System.out.println("➡ " + e.getMessage());
                    }
                }
            } catch (IOException e) {
                System.out.println("❌ Error Loading clients: " + e.getMessage());
            }
        }

        if (userType == null || userType.isEmpty() || userType.equals("Doctor")) {
            try (Scanner scanner = new Scanner(new File(DOCTORS_FILE))) {
                if (!scanner.hasNextLine()) {
                    throw new IOException("❌ No Doctors found to display.");
                }

                if (scanner.hasNextLine()) {
                    scanner.nextLine();
                }

                while (scanner.hasNextLine()) {
                    String[] parts = scanner.nextLine().split(",");
                    try {
                        int id = Integer.parseInt(parts[0]);
                        String name = parts[1];
                        String username = parts[2];
                        String password = parts[3];
                        String phone = parts[4];
                        String dateOfBirth = parts[5];
                        String startTime = parts[6];
                        String endTime = parts[7];
                        double salary = Double.parseDouble(parts[8]);
                        int licenseNumber = Integer.parseInt(parts[9]);

                        allUsers.add(new Doctor(id, name, username, password, phone, dateOfBirth, startTime, endTime,
                                salary, licenseNumber));
                    } catch (NumberFormatException e) {
                        System.out.println("➡ " + e.getMessage());
                    }
                }
            } catch (IOException e) {
                System.out.println("❌ Error Loading doctors: " + e.getMessage());
            }
        }

        if (userType == null || userType.isEmpty() || userType.equals("Admin")) {
            try (Scanner scanner = new Scanner(new File(ADMINS_FILE))) {
                if (!scanner.hasNextLine()) {
                    throw new IOException("❌ No Admins found to display.");
                }

                if (scanner.hasNextLine()) {
                    scanner.nextLine();
                }

                while (scanner.hasNextLine()) {
                    String[] parts = scanner.nextLine().split(",");
                    try {
                        int id = Integer.parseInt(parts[0]);
                        String name = parts[1];
                        String username = parts[2];
                        String password = parts[3];
                        String phone = parts[4];
                        String dateOfBirth = parts[5];
                        String startTime = parts[6];
                        String endTime = parts[7];
                        double salary = Double.parseDouble(parts[8]);

                        allUsers.add(new Admin(id, name, username, password, phone, dateOfBirth, startTime, endTime,
                                salary));

                    } catch (NumberFormatException e) {
                        System.out.println("➡ " + e.getMessage());
                    }
                }
            } catch (IOException e) {
                System.out.println("❌ Error Loading admins: " + e.getMessage());
            }
        }

        if (userType != null && !userType.equals("Client") && !userType.equals("Doctor")
                && !userType.equals("Admin")) {
            System.out.println("❌ Invalid user type! try again.");
            return null;
        }

        return allUsers;
    }

    public static ArrayList<Medicine> searchMedicines(String input) {
        ArrayList<Medicine> foundMedicines = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(MEDICINES_FILE))) {
            if (scanner.hasNextLine()) {
                scanner.nextLine();
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                try {
                    if ((parts[0] + parts[1] + parts[2] + parts[3] + parts[4] + parts[5] + parts[9] + parts[10]).toLowerCase()
                            .matches(".*" + input.toLowerCase() + ".*")) {
                        int id = Integer.parseInt(parts[0]);
                        String name = parts[1];
                        String composition = parts[2];
                        double price = Double.parseDouble(parts[3]);
                        int stock = Integer.parseInt(parts[4]);
                        String manufacturer = parts[5];
                        LocalDate manufactureDate = LocalDate.parse(parts[6], dateFormatter);
                        LocalDate expirationDate = LocalDate.parse(parts[7], dateFormatter);
                        String uses = parts[9];
                        String sideEffects = parts[10];
                        String ImageUrl = parts[11].isEmpty() ? "" : parts[11].trim().replaceAll("\"", "");

                        ArrayList<String> prescribed = new ArrayList<>();
                        if (!parts[8].equals("NULL")) {
                            prescribed.addAll(Arrays.asList(parts[8].split("\\|")));
                        } else {
                            prescribed = null;
                        }

                        Medicine foundMedicine = new Medicine(id, name, composition, price, stock, manufacturer, manufactureDate,
                                expirationDate, prescribed, uses, sideEffects, ImageUrl);
                        foundMedicine.displayInfo();
                        foundMedicines.add(foundMedicine);
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Error➡ " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Error reading medicines.csv: " + e.getMessage());
        }

        if (foundMedicines.isEmpty()) {
            System.out.println("⚠️ Medicines not found.");
        }

        return foundMedicines;
    }

    public static boolean checkUsername(String username) {
        ArrayList<String> allUsername = new ArrayList<>();
        ArrayList<User> allUsers = loadAllUsers(null);

        for (User user : allUsers) {
            allUsername.add(user.getUsername());
        }
        return !allUsername.contains(username);

    }

    public static boolean writeInFile(String filePath, ArrayList<String> parts) {

        try (FileWriter writer = new FileWriter(filePath)) {
            for (String part : parts) {
                writer.write(part + "\n");
            }
            return true;
        } catch (IOException e) {
            System.out.println("❌ Error updating: " + e.getMessage());
            return false;
        }
    }

    public static int getIntInput(Scanner s, String message) {
        while (true) {
            System.out.print(message);
            if (s.hasNextInt()) {
                int input = s.nextInt();
                if (input < 0) {
                    System.out.println("❌ Invalid input! Please enter a positive number.");
                    s.nextLine();
                } else {
                    s.nextLine();
                    return input;
                }
            } else {
                System.out.println("❌ Invalid input! Please enter a valid number.");
                s.nextLine();
            }
        }
    }

    public static double getDoubleInput(Scanner s, String message) {
        while (true) {
            System.out.print(message);
            if (s.hasNextDouble()) {
                double input = s.nextDouble();
                if (input < 0) {
                    System.out.println("❌ Invalid input! Please enter a positive number.");
                } else {
                    return input;
                }
            } else {
                System.out.println("❌ Invalid input! Please enter a valid decimal number.");
                s.nextLine();
            }
        }
    }

    public static String getStringInput(Scanner s, String message) {
        while (true) {
            System.out.print(message);
            String input = s.nextLine();
            if (!input.contains(",")) {
                return input;
            } else {
                System.out.println("❌ Invalid input! Commas are not allowed. Please try again.");
            }
        }
    }

    public static void viewAllUsers() {
        ArrayList<User> allUsers = loadAllUsers(null);

        if (allUsers.isEmpty()) {
            System.out.println("❌ No users to manage");
            return;
        }

        for (User user : allUsers) {
            user.displayInfo();
        }
    }

    public static LocalDate getDateInput(Scanner s, String message) {
        DateTimeFormatter DateFormatter = DateTimeFormatter.ofPattern("d/M/yyyy");

        while (true) {
            System.out.print(message);
            String input = s.nextLine().trim();

            if (input.isEmpty() || input.equals("")) {
                return null;
            }

            try {
                return LocalDate.parse(input, DateFormatter);
            } catch (DateTimeParseException e) {
                System.out.println("❌ Invalid date format! Please enter the date in d/m/yyyy format.");
            }
        }
    }

    public static boolean checkLicenseNumber(int licenseNumber) {
        ArrayList<Integer> allLicenseNumber = new ArrayList<>();
        ArrayList<User> allUsers = loadAllUsers("Doctor");

        for (User user : allUsers) {
            allLicenseNumber.add(((Doctor) user).getLicenseNumber());
        }
        return !allLicenseNumber.contains(licenseNumber);
    }

    public static void clear() {
        System.out.println("\n".repeat(50));
        System.out.println("--- SCREEN CLEARED ---");
    }

}
