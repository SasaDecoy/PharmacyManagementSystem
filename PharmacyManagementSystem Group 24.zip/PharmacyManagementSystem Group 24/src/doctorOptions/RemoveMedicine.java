package doctorOptions;

import publicOptions.ViewAllMedicines;
import mainClasses.*;
import java.io.*;
import java.util.*;

import static utils.CommonFunctions.*;

public class RemoveMedicine implements Option {

    private static final String MEDICINES_FILE = "Data/medicines.csv";

    @Override
    public String getOption() {
        return "❌ Remove Medicine";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- Remove Medicine ---");
        new ViewAllMedicines().oper(s, u);
        while (true) {
            String input = getStringInput(s, "Enter Medicine ID or Name to remove (0 to exit): ");

            if (input.equals("0")) {
                System.out.println("\n==Returning to menu==");
                break;
            }
            
            ArrayList<String> updatedMedicines = new ArrayList<>();
            boolean found = false;
            
            try (Scanner scanner = new Scanner(new File(MEDICINES_FILE))) {
                if (scanner.hasNextLine()) {
                    updatedMedicines.add(scanner.nextLine());
                }

                while (scanner.hasNextLine()) {
                    String[] parts = scanner.nextLine().split(",");
                    try {
                        String medicineId = parts[0];
                        String medicineName = parts[1];

                        if (medicineId.equals(input) || medicineName.equalsIgnoreCase(input)) {
                            found = true;
                            System.out.println("✅ Medicine removed: " + medicineName);
                        } else {
                            updatedMedicines.add(String.join(",", parts));
                        }

                    } catch (NumberFormatException e) {
                        System.out.println("Error➡ " + e.getMessage());
                    }
                }
            } catch (IOException e) {
                System.out.println("❌ Error reading medicines.csv: " + e.getMessage());
                return;
            }

            if (!found) {
                System.out.println("❌ No medicine found with the given ID or name! Try again.");
                continue;
            }

            if (writeInFile(MEDICINES_FILE, updatedMedicines)) {

                System.out.println("✅ Medicine removed successfully!");
            } else {
                System.out.println("❌ Medicine couldn't be removed");
            }
        }
    }
}
