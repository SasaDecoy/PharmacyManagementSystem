package doctorOptions;

import java.io.*;
import java.util.*;
import mainClasses.Medicine;
import mainClasses.Option;
import mainClasses.User;
import publicOptions.ViewAllMedicines;
import static utils.CommonFunctions.*;

public class AddPrescription implements Option {

    private static final String MEDICINES_FILE = "Data/medicines.csv";

    @Override
    public String getOption() {
        return "🏥 Add Prescription";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- Add Prescripiton ---");
        int medId;
        int userId = 0;
        Medicine selectedMed = null;

        new ViewAllMedicines().oper(s, u);

        while (true) {
            medId = getIntInput(s, "Enter Medicine ID to add prescripiton (0 to Exit): ");

            if (medId == 0) {
                System.out.println("\n==Returning to menu==");
                return;
            }

            selectedMed = findMedicineById(medId);

            if (selectedMed == null) {
                System.out.println("❌ Invalid medicine ID. Try again.");
                continue;
            } else if (selectedMed.getPrescribed() == null) {
                System.out.println("❌ Medicine doesn't need prescription.");
                continue;
            }
            break;
        }

        while (true) {
            userId = getIntInput(s, "Enter client ID (0 to Exit): ");

            if (userId == 0) {
                System.out.println("\n==Returning to menu==");

                return;
            }

            for (User c : loadAllUsers("Client")) {
                if (userId == c.getId()) {
                    System.out.println("✅ Medicine and Client Found adding prescription");
                    break;
                }
            }
            break;
        }

        ArrayList<String> updatedMedicines = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(MEDICINES_FILE))) {
            if (scanner.hasNextLine()) {
                updatedMedicines.add(scanner.nextLine());
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");
                try {
                    if (parts[0].equals(String.valueOf(selectedMed.getId())) && !selectedMed.getPrescribed().contains(userId)) {
                        String currentUsers = parts[8];
                        currentUsers += userId  + "|";
                        parts[8] = currentUsers;
                    }

                    updatedMedicines.add(String.join(",", parts));

                } catch (NumberFormatException e) {
                    System.out.println("Error➡ " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Error reading medicines.csv: " + e.getMessage());
            return;
        }

        if (writeInFile(MEDICINES_FILE, updatedMedicines)) {
            System.out.println("✅ Medicines file updated successfully!");
        } else {
            System.out.println("❌ Medicines couldn't be updated.");
        }

    }

}
