package doctorOptions;

import java.time.LocalDate;
import java.util.*;
import mainClasses.*;
import static utils.CommonFunctions.*;

public class AddMedicine implements Option {

    @Override
    public String getOption() {
        return "➕ Add Medicine";
    }

    @Override
    public void oper(Scanner s, User u) {
        ArrayList<Medicine> allMedicines = loadMedicines();
        ArrayList<String> allMedicinesNames = new ArrayList<>();

        if (!allMedicines.isEmpty()) {
            for (Medicine med : allMedicines) {
                allMedicinesNames.add(med.getName().toLowerCase());
            }
        }

        System.out.println("\n--- Add New Medicine ---");

        String name;
        while (true) {
            if (!allMedicinesNames.isEmpty()) {
                name = getStringInput(s, "Enter Medicine Name: ");
                if (allMedicinesNames.contains(name.toLowerCase())) {
                    System.out.println("⚠️ Medicine already Exists!");
                } else {
                    break;
                }
            } else {
                name = getStringInput(s, "Enter Medicine Name: ");
                break;
            }
        }

        String composition = getStringInput(s, "Enter Medicine Composition: ");

        double price = getDoubleInput(s, "Enter Price: ");

        int stock = getIntInput(s, "Enter Stock Quantity: ");

        String manufacturer = getStringInput(s, "Enter Manufacturer: ");

        LocalDate manufactureDate = getDateInput(s, "Enter Manufacture Date (D/M/YYYY): ");

        LocalDate expirationDate = getDateInput(s, "Enter Expiration Date (D/M/YYYY): ");

        String prescribedString = "";
        while (!(prescribedString.equalsIgnoreCase("Y") || prescribedString.equalsIgnoreCase("N"))) {
            prescribedString = getStringInput(s, "Does this Medication Require a prescription (Y/N): ");
        }

        ArrayList<String> prescribed = prescribedString.equalsIgnoreCase("Y") ? new ArrayList<>() : null;

        String uses = getStringInput(s, "Enter Uses: ");

        String sideEffects = getStringInput(s, "Enter Side Effects: ");
        
        String ImageUrl = getStringInput(s, "Enter ImageUrl: ");

        new Medicine(name, composition, price, stock, manufacturer, manufactureDate, expirationDate, prescribed, uses, sideEffects, ImageUrl);
        System.out.println("✅ Medicine added successfully!");
    }
}
