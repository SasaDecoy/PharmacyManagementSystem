package doctorOptions;

import java.io.*;
import java.util.*;
import mainClasses.*;
import publicOptions.ViewAllMedicines;
import static utils.CommonFunctions.*;

public class RemovePrescription implements Option {

    private static final String MEDICINES_FILE = "Data/medicines.csv";

    @Override
    public String getOption() {
        return "❌ Remove Prescription";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- Remove Prescription ---");
        int medId;
        String userId = null;
        Medicine selectedMed = null;
        new ViewAllMedicines().oper(s, u);
        while (true) {
            medId = getIntInput(s, "Enter Medicine ID to remove prescription from (0 to Exit): ");

            if (medId == 0) {
                System.out.println("\n==Returning to menu==");
                return;
            }

            selectedMed = findMedicineById(medId);

            if (selectedMed == null) {
                System.out.println("❌ Invalid medicine ID. Try again.");
                continue;
            } else if (selectedMed.getPrescribed() == null) {
                System.out.println("❌ This medicine doesn't need prescription! Try again.");
                continue;
            }
            break;
        }

        viewAllUsers();
        while (true) {

            userId = getStringInput(s, "Enter client ID to remove (0 to Exit): ");

            if (userId.equals("0")) {
                return;
            }
            if (selectedMed.getPrescribed().contains(userId)) {
                break;
            } else {
                System.out.println("❌ This client is not prescribed this medicine.");
            }
            break;
        }

        ArrayList<String> updatedMedicines = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(MEDICINES_FILE))) {
            if (scanner.hasNextLine()) {
                updatedMedicines.add(scanner.nextLine());
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");
                try {
                    if (parts[0].equals(String.valueOf(selectedMed.getId())) && selectedMed.getPrescribed().contains(userId)) {
                        String[] prescribedUsers = parts[8].split("\\|");
                        ArrayList<String> updatedUsers = new ArrayList<>(Arrays.asList(prescribedUsers));
                        updatedUsers.remove(userId);
                        parts[8] = String.join("|", updatedUsers);
                    }

                    updatedMedicines.add(String.join(",", parts));
                } catch (NumberFormatException e) {
                    System.out.println("Error➡ " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Error reading medicines.csv: " + e.getMessage());
            return;
        }

        if (writeInFile(MEDICINES_FILE, updatedMedicines)) {
            System.out.println("✅ Prescription removed successfully!");
        } else {
            System.out.println("❌ Prescription couldn't be removed.");
        }
    }

}
