package doctorOptions;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import mainClasses.Option;
import mainClasses.User;
import publicOptions.ViewAllMedicines;
import static utils.CommonFunctions.*;

public class UpdateMedicine implements Option {

    private static final String MEDICINES_FILE = "Data/medicines.csv";
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d/M/yyyy");

    @Override
    public String getOption() {
        return "✏ Update Medicine";
    }

    @Override
    public void oper(Scanner s, User u) {
        System.out.println("\n--- Update Medicine ---");
        new ViewAllMedicines().oper(s, u);

        String input = getStringInput(s, "Enter Medicine ID or Name to update (0 to exit): ");

        if (input.equals("0")) {
            System.out.println("\n==Returning to menu==");
            return;
        }

        ArrayList<String> updatedMedicines = new ArrayList<>();
        boolean found = false;

        try (Scanner scanner = new Scanner(new File(MEDICINES_FILE))) {
            if (scanner.hasNextLine()) {
                updatedMedicines.add(scanner.nextLine());
            }

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");

                if (parts[0].equals(input) || parts[1].equalsIgnoreCase(input)) {
                    found = true;
                    System.out.println("Editing Medicine: " + parts[1]);

                    while (true) {
                        System.out.println("\n1. Edit Name: ");
                        System.out.println("2. Edit Composition: ");
                        System.out.println("3. Edit Price: ");
                        System.out.println("4. Edit Stock Quantity: ");
                        System.out.println("5. Edit Manufacturer: ");
                        System.out.println("6. Edit Manufacture Date (d/M/yyyy): ");
                        System.out.println("7. Edit Expiration Date (d/M/yyyy): ");
                        System.out.println("8. Edit Uses: ");
                        System.out.println("9. Edit Side Effects: ");
                        System.out.println("0. Finish Editing");

                        int choice = getIntInput(s, "Enter Your choice: ");

                        if (choice == 0) {
                            break;
                        }

                        switch (choice) {
                            case 1 -> {
                                String newName = getStringInput(s, "Enter new Name (" + parts[1] + "): ");
                                parts[1] = newName.isEmpty() ? parts[1] : newName;
                            }
                            case 2 -> {
                                String newComposition = getStringInput(s, "Enter new Composition (" + parts[2] + "): ");
                                parts[2] = newComposition.isEmpty() ? parts[2] : newComposition;
                            }
                            case 3 -> {
                                double newPrice = getDoubleInput(s, "Enter new Price (" + parts[3] + "): ");
                                parts[3] = newPrice == 0 ? parts[3] : String.valueOf(newPrice);
                            }
                            case 4 -> {
                                int newStock = getIntInput(s, "Enter new Stock Quantity (" + parts[4] + "): ");
                                parts[4] = newStock == 0 ? parts[4] : String.valueOf(newStock);
                            }
                            case 5 -> {
                                String newManufacturer = getStringInput(s, "Enter new Manufacturer (" + parts[5] + "): ");
                                parts[5] = newManufacturer.isEmpty() ? parts[5] : newManufacturer;
                            }
                            case 6 -> {
                                LocalDate newManufacturerDate = getDateInput(s, "Enter new Manufacturer Date (d/M/yyyy) (" + parts[6] + "): ");
                                parts[6] = newManufacturerDate == null ? parts[6] : newManufacturerDate.format(dateFormatter);
                            }
                            case 7 -> {
                                LocalDate newExpirationDate = getDateInput(s, "Enter new Expiration Date (d/M/yyyy) (" + parts[7] + "): ");
                                parts[7] = newExpirationDate == null ? parts[7] : newExpirationDate.format(dateFormatter);
                            }
                            case 8 -> {
                                String newUses = getStringInput(s, "Enter new Uses (" + parts[8] + "): ");
                                parts[8] = newUses.isEmpty() ? parts[8] : newUses;
                            }
                            case 9 -> {
                                String newSideEffects = getStringInput(s, "Enter new Side Effects (" + parts[9] + "): ");
                                parts[9] = newSideEffects.isEmpty() ? parts[9] : newSideEffects;
                            }
                            default -> {
                                System.out.println("❌ Invalid Choice!");
                            }
                        }
                    }
                }
                
                updatedMedicines.add(String.join(",", parts));
            }
        } catch (IOException e) {
            System.out.println("❌ Error reading medicines.csv: " + e.getMessage());
            return;
        }

        if (!found) {
            System.out.println("❌ No medicine found with the given ID or name.");
            return;
        } else {

            if (writeInFile(MEDICINES_FILE, updatedMedicines)) {
                System.out.println("✅ Medicines file updated successfully!");
            } else {
                System.out.println("❌ Medicines file couldn't be updated.");
            }
        }

    }
}
