package mainClasses;

import publicOptions.ViewAllMedicines;
import publicOptions.SearchMedicine;
import doctorOptions.*;
import java.io.*;
import publicOptions.*;

public class Doctor extends User {

    private static final String DOCTORS_FILE = "Data/doctors.csv";
    private String startTime;
    private String endTime;
    private double salary;
    private int licenseNumber;

    public Doctor(int id, String name, String username, String password, String phone, String dateOfBirth,
            String startTime, String endTime, double salary, int licenseNumber) {
        super(id, name, username, password, phone, dateOfBirth, new Option[]{
            new ManageAccount(),
            new AddMedicine(),
            new RemoveMedicine(),
            new UpdateMedicine(),
            new SearchMedicine(),
            new ViewAllMedicines(),
            new AddPrescription(),
            new RemovePrescription(),

        });
        this.startTime = startTime;
        this.endTime = endTime;
        this.salary = salary;
        this.licenseNumber = licenseNumber;
    }

    public Doctor(String name, String username, String password, String phone, String dateOfBirth,
            String startTime, String endTime, double salary, int licenseNumber) {
        super(name, username, password, phone, dateOfBirth, new Option[]{});
        this.startTime = startTime;
        this.endTime = endTime;
        this.salary = salary;
        this.licenseNumber = licenseNumber;
        saveToCSV();
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(int licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    @Override
    public void displayInfo() {
        System.out.println("Doctor ID: " + getId());
        System.out.println("Name: " + getName());
        System.out.println("Username: " + getUsername());
        System.out.println("Phone: " + getPhone());
        System.out.println("Date of Birth: " + getDateOfBirth());
        System.out.println("Start Time: " + startTime);
        System.out.println("End Time: " + endTime);
        System.out.println("Salary: $" + salary);
        System.out.println("Work Hours: " + licenseNumber);
        System.out.println("Role: Doctor");
        System.out.println("------------------------------------");
    }

    private void saveToCSV() {
        try (FileWriter writer = new FileWriter(DOCTORS_FILE, true)) {
            writer.write(getId() + "," + getName() + "," + getUsername() + "," + getPassword() + ","
                    + getPhone() + "," + getDateOfBirth() + "," + startTime + "," + endTime + ","
                    + salary + "," + licenseNumber + "\n");
        } catch (IOException e) {
            System.out.println("Error saving doctor to CSV: " + e.getMessage());
        }
    }
}
