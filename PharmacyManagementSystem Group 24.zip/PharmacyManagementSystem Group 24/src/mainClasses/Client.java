package mainClasses;

import clientOptions.*;
import java.io.*;
import publicOptions.*;

public class Client extends User {

    private static final String CLIENTS_FILE = "Data/clients.csv";

    public Client(int id, String name, String username, String password, String phone, String dateOfBirth) {
        super(id, name, username, password, phone, dateOfBirth, new Option[]{
            new ManageAccount(),
//            new OrderMedicine(),
//            new CancelOrder(),
//            new UpdateOrder(),
            new ViewOrders(),
            new SearchMedicine(),
            new ViewAllMedicines(),
//            new SearchOrders(),
            new ContactDoctor(),
        });
    }

    public Client(String name, String username, String password, String phone, String dateOfBirth) {
        super(name, username, password, phone, dateOfBirth, new Option[]{});
        saveToCSV();
    }

    @Override
    public void displayInfo() {
        System.out.println("Client ID: " + getId());
        System.out.println("Name: " + getName());
        System.out.println("Username: " + getUsername());
        System.out.println("Phone: " + getPhone());
        System.out.println("Date of Birth: " + getDateOfBirth());
        System.out.println("------------------------------------");
    }

    private void saveToCSV() {
        try (FileWriter writer = new FileWriter(CLIENTS_FILE, true)) {
            writer.write(getId() + "," + getName() + "," + getUsername() + "," + getPassword() + ","
                    + getPhone() + "," + getDateOfBirth() + "\n");
        } catch (IOException e) {
            System.out.println("Error saving client to CSV: " + e.getMessage());
        }
    }
}
