package mainClasses;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Medicine {

    private static final String MEDICINES_FILE = "Data/medicines.csv";
    private static final String ID_FILE = "Data/last_medicine_id.csv";
    private static int idCounter = loadLastId();
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d/M/yyyy");

    private int id;
    private String name;
    private String composition;
    private double price;
    private int stock;
    private String manufacturer;
    private LocalDate manufactureDate;
    private LocalDate expirationDate;
    private ArrayList<String> prescribed;
    private String uses;
    private String sideEffects;
    private String ImageUrl;

    public Medicine(String name, String composition, double price, int stock, String manufacturer, LocalDate manufactureDate, LocalDate expirationDate, ArrayList<String> prescribed, String uses, String sideEffects, String ImageUrl) {
        this.id = idCounter++;
        this.name = name;
        this.composition = composition;
        this.price = price;
        this.stock = stock;
        this.manufacturer = manufacturer;
        this.manufactureDate = manufactureDate;
        this.expirationDate = expirationDate;
        this.prescribed = prescribed;
        this.uses = uses;
        this.sideEffects = sideEffects;
        this.ImageUrl = ImageUrl;
        saveLastId();
        saveToCSV();
    }

    public Medicine(int id, String name, String composition, double price, int stock, String manufacturer, LocalDate manufactureDate, LocalDate expirationDate, ArrayList<String> prescribed, String uses, String sideEffects, String ImageUrl) {
        this.id = id;
        this.name = name;
        this.composition = composition;
        this.price = price;
        this.stock = stock;
        this.manufacturer = manufacturer;
        this.manufactureDate = manufactureDate;
        this.expirationDate = expirationDate;
        this.prescribed = prescribed;
        this.uses = uses;
        this.sideEffects = sideEffects;
        this.ImageUrl = ImageUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public void setImageUrl(String imageUrl){
        this.ImageUrl = ImageUrl;
    }
    
    public String getImageUrl()
    {
        return ImageUrl;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComposition() {
        return composition;
    }

    public void setComposition(String composition) {
        this.composition = composition;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public DateTimeFormatter getDateFormatter() {
        return dateFormatter;
    }

    public LocalDate getManufactureDate() {
        return manufactureDate;
    }

    public void setManufactureDate(LocalDate manufactureDate) {
        this.manufactureDate = manufactureDate;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    public ArrayList<String> getPrescribed() {
        return prescribed;
    }

    public void setUses(String uses) {
        this.uses = uses;
    }

    public String getUses() {
        return uses;
    }

    public void setSideEffects(String sideEffects) {
        this.sideEffects = sideEffects;
    }

    public String getSideEffects() {
        return sideEffects;
    }

    private void saveToCSV() {
        try (FileWriter writer = new FileWriter(MEDICINES_FILE, true)) {
            writer.write(id + "," + name + "," + composition + "," + price + "," + stock
                    + "," + manufacturer + "," + manufactureDate.format(dateFormatter)
                    + "," + expirationDate.format(dateFormatter) + ","
                    + (prescribed != null ? String.join("|", prescribed) : "NULL")
                    + "," + uses + "," + sideEffects + "\n");
        } catch (IOException e) {
            System.out.println("❌ Error saving medicine: " + e.getMessage());
        }
    }

    private static void saveLastId() {
        try (FileWriter writer = new FileWriter(ID_FILE)) {
            writer.write(String.valueOf(idCounter));
        } catch (IOException e) {
            System.out.println("❌ Error saving last medicine ID: " + e.getMessage());
        }
    }

    private static int loadLastId() {
        try (Scanner scanner = new Scanner(new File(ID_FILE))) {
            if (scanner.hasNextInt()) {
                return scanner.nextInt();
            }
        } catch (IOException e) {
            System.out.println("❌ Error loading last medicine ID: " + e.getMessage());
        }
        return 1;
    }

    public void displayInfo() {
        System.out.println("Medicine ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Composition: " + composition);
        System.out.println("Price: $" + price);
        System.out.println("Stock: " + stock);
        System.out.println("Manufacturer: " + manufacturer);
        System.out.println("Manufacture Date: " + manufactureDate.format(dateFormatter));
        System.out.println("Expiration Date: " + expirationDate.format(dateFormatter));
        System.out.println("Requires Perscription: " + (prescribed != null));
        System.out.println("Uses: " + uses);
        System.out.println("Side Effects: " + sideEffects);
        System.out.println("------------------------------------");
    }
}
