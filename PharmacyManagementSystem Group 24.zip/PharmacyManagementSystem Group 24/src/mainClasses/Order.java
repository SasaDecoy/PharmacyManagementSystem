package mainClasses;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Order {

    private static final String ORDERS_FILE = "Data/orders.csv";
    private static final String ID_FILE = "Data/last_order_id.csv";
    private static int idCounter = loadLastId();
    private static DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d/M/yyyy");

    private int customerId;
    private int orderId;
    private String orderStatus;
    private ArrayList<Medicine> medicines;
    private ArrayList<Integer> quantities;
    private double totalPrice;
    private double amountPaid;
    private double changeAmount;
    private LocalDate orderDate;

    public Order(int customerId, ArrayList<Medicine> medicines, ArrayList<Integer> quantities, double totalPrice, double amountPaid, double changeAmount, String orderStatus) {
        this.orderId = idCounter++;
        this.customerId = customerId;
        this.medicines = new ArrayList<>(medicines);
        this.quantities = new ArrayList<>(quantities);
        this.totalPrice = totalPrice;
        this.amountPaid = amountPaid;
        this.orderStatus = orderStatus;
        this.changeAmount = changeAmount;
        this.orderDate = LocalDate.now();
        saveLastId();
        saveToCSV();
    }

    public Order(int orderId, int customerId, ArrayList<Medicine> medicines, ArrayList<Integer> quantities, double totalPrice, double amountPaid, double changeAmount, String orderStatus,
            LocalDate orderDate) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.medicines = new ArrayList<>(medicines);
        this.quantities = new ArrayList<>(quantities);
        this.totalPrice = totalPrice;
        this.amountPaid = amountPaid;
        this.orderStatus = orderStatus;
        this.changeAmount = changeAmount;
        this.orderDate = orderDate;
    }

    public int getOrderId() {
        return orderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public ArrayList<Medicine> getMedicines() {
        return medicines;
    }

    public void setMedicines(ArrayList<Medicine> medicines) {
        this.medicines = medicines;
    }

    public ArrayList<Integer> getQuantities() {
        return quantities;
    }

    public void setQuantities(ArrayList<Integer> quantities) {
        this.quantities = quantities;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public double getChangeAmount() {
        return changeAmount;
    }

    public void setChangeAmount(double changeAmount) {
        this.changeAmount = changeAmount;
    }

    private void saveToCSV() {
        try (FileWriter writer = new FileWriter(ORDERS_FILE, true)) {
            String orderLine = orderId + "," + customerId + ",";

            for (int i = 0; i < medicines.size(); i++) {
                orderLine += medicines.get(i).getId() + "-" + quantities.get(i) + "|";
            }

            orderLine += "," + totalPrice + "," + amountPaid + "," + changeAmount + "," + orderStatus + "," + orderDate.format(dateFormatter) + "\n";

            writer.write(orderLine);
        } catch (IOException e) {
            System.out.println("❌ Error saving order: " + e.getMessage());
        }
    }

    private static void saveLastId() {
        try (FileWriter writer = new FileWriter(ID_FILE)) {
            writer.write(String.valueOf(idCounter));
        } catch (IOException e) {
            System.out.println("❌ Error saving last order ID: " + e.getMessage());
        }
    }

    private static int loadLastId() {
        try (Scanner scanner = new Scanner(new File(ID_FILE))) {
            if (scanner.hasNextInt()) {
                return scanner.nextInt();
            }
        } catch (IOException e) {
            System.out.println("❌ Error loading last order ID: " + e.getMessage());
        }
        return 1;
    }

    public void displayInfo() {
        System.out.println("\n📦 Order ID: " + orderId);
        System.out.println("📅 Order Date: " + orderDate.format(dateFormatter));
        System.out.println("Medicines Ordered:");
        for (int i = 0; i < medicines.size(); i++) {
            System.out.println("- " + medicines.get(i).getName() + " (Qty: " + quantities.get(i) + ") - $" + (medicines.get(i).getPrice() * quantities.get(i)));
        }
        System.out.println("Total Price: $" + totalPrice);
        System.out.println("Amount Paid: $" + amountPaid);
        System.out.println("Remaining Balance: $" + changeAmount);
        System.out.println("Order Status: " + orderStatus);
        System.out.println("------------------------------------");

    }
}
