package mainClasses;

import publicOptions.ViewAllMedicines;
import adminOptions.*;
import doctorOptions.*;
import java.io.*;
import publicOptions.*;

public class Admin extends User {

    private static final String ADMINS_FILE = "Data/admins.csv";
    private String startTime;
    private String endTime;
    private double salary;

    public Admin(int id, String name, String username, String password, String phone, String dateOfBirth, String startTime, String endTime, double salary) {
        super(id, name, username, password, phone, dateOfBirth, new Option[]{
            new CreateUser(),
            new ManageUsers(),
            new ManageAccount(),
            new AddMedicine(),
            new RemoveMedicine(),
            new UpdateMedicine(),
            new ViewAllMedicines(),
            new GenerateReports(),
            new SearchMedicine()
        });
        this.startTime = startTime;
        this.endTime = endTime;
        this.salary = salary;

    }

    public Admin(String name, String username, String password, String phone, String dateOfBirth, String startTime, String endTime, double salary) {
        super(name, username, password, phone, dateOfBirth, new Option[]{});
        this.startTime = startTime;
        this.endTime = endTime;
        this.salary = salary;
   
        saveToCSV();
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public void displayInfo() {
        System.out.println("Admin ID: " + getId());
        System.out.println("Name: " + getName());
        System.out.println("Username: " + getUsername());
        System.out.println("Phone: " + getPhone());
        System.out.println("Date of Birth: " + getDateOfBirth());
        System.out.println("Start Time: " + startTime);
        System.out.println("End Time: " + endTime);
        System.out.println("Salary: $" + salary);
        System.out.println("Role: Administrator");
        System.out.println("------------------------------------");
    }

    private void saveToCSV() {
        try (FileWriter writer = new FileWriter(ADMINS_FILE, true)) {
            writer.write(getId() + "," + getName() + "," + getUsername() + "," + getPassword() + ","
                    + getPhone() + "," + getDateOfBirth() + "," + startTime + "," + endTime + ","
                    + salary + "\n");
        } catch (IOException e) {
            System.out.println("Error saving admin to CSV: " + e.getMessage());
        }
    }
}
