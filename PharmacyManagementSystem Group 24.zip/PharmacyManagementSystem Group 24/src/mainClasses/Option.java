package mainClasses;

import java.util.Scanner;

public interface Option {

    abstract String getOption();

    abstract void oper(Scanner s, User u);
}
