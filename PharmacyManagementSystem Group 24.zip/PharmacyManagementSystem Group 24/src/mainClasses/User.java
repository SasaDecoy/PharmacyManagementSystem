package mainClasses;

import java.io.*;
import java.util.Scanner;
import static utils.CommonFunctions.*;

public abstract class User {

    private static String ID_FILE = "Data/last_id.csv";
    private static int idCounter = loadLastID();
    private int id;
    private String name;
    private String username;
    private String password;
    private String phone;
    private String dateOfBirth;
    protected Option[] options;

    public User(int id, String name, String username, String password, String phone, String dateOfBirth, Option[] options) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.password = password;
        this.phone = phone;
        this.dateOfBirth = dateOfBirth;
        this.options = options;
    }

    public User(String name, String username, String password, String phone, String dateOfBirth, Option[] options) {
        this.id = idCounter++;
        this.name = name;
        this.username = username;
        this.password = password;
        this.phone = phone;
        this.dateOfBirth = dateOfBirth;
        this.options = options;
        saveLastID();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Option[] getOptions() {
        return options;
    }

    public void setOptions(Option[] options) {
        this.options = options;
    }

    public abstract void displayInfo();

    public void showOptions(Scanner s) {
        while (true) {
            System.out.println("\n");
            for (int i = 0; i < options.length; i++) {
                System.out.println((i + 1) + ". " + options[i].getOption()); 
            }
            System.out.println("0. Exit");
            
            int choice = getIntInput(s, "Choose an option: ");

            if (choice == 0) {
                break;
            }

            if (choice > 0 && choice <= options.length) {
                clear();
                options[choice - 1].oper(s, this);
            } else {
                System.out.println("❌ Invalid choice, try again.");
            }
        }
    }

    private static void saveLastID() {
        try (FileWriter writer = new FileWriter(ID_FILE)) {
            writer.write(String.valueOf(idCounter));
        } catch (IOException e) {
            System.out.println("Error Saving last ID: " + e.getMessage());
        }
    }

    private static int loadLastID() {
        try (Scanner scanner = new Scanner(new File(ID_FILE))) {
            if (scanner.hasNextInt()) {
                return scanner.nextInt();
            }
        } catch (IOException e) {
            System.out.println("Error Loading Last ID: " + e.getMessage());
        }
        return 1;
    }
}
